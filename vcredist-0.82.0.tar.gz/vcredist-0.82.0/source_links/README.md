# Source Links Archive

## Microsoft Visual C++ 2015-2022 Redistributables - v14

<details><summary>2022</summary>


14.40.33807.0
```
https://download.visualstudio.microsoft.com/download/pr/9df86759-7290-413e-9158-98ad1aece86e/4EB7E6B9B1F09AA879A7984A353F0CBD5DEC9FFC5309E1E7B589E77A0560A9CF/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/c7c1679b-4bc9-4f2c-99c0-57092954ba51/2128B998BAE8C5B7172E5E3336C82EC430A096EDC1190F13BCD496156F0DD427/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/9df86759-7290-413e-9158-98ad1aece86e/1E903A6CD097D8F3126E48607BCA050C643928475EF3E05A2D8B4780F2E63391/VC_redist.arm64.exe
```

14.40.33721.2
```
https://download.visualstudio.microsoft.com/download/pr/113d16d7-044c-4a0b-a81f-988dc51d2b1f/D24162483BF15A53D8C93636396BF001DEC8BBBFA2C0357B7BD5C6424C1B1C64/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/113d16d7-044c-4a0b-a81f-988dc51d2b1f/17D04E833349D2C014C0BE79CE22C069BF91147C0E546F2D30592F455773DABD/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/113d16d7-044c-4a0b-a81f-988dc51d2b1f/F59B90AF464E83B00C0C2950DBED75D7739F6D9AF9EF72806202C6D3C4B3B3EA/VC_redist.arm64.exe
```

14.40.33617.1
```
https://download.visualstudio.microsoft.com/download/pr/09ee6168-4ebc-4886-a058-a668f573a552/CAA8369F99545E84E0EA83CBE0C202408F3B3A038B2E1786BB048A837A9D1522/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/09ee6168-4ebc-4886-a058-a668f573a552/E13808974666DACAAEA5C748E1CA3B39992541FE9FE393DA6FBAACF21273CF1A/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/b7289999-75be-4ef1-96eb-294e1d7edf7e/767250E582AFD6139FF6F29872A78AE879DE50FEA15AEAD39FB5A62DBD6D3B52/VC_redist.arm64.exe
```

14.38.33135.0
```
https://download.visualstudio.microsoft.com/download/pr/34922e31-a9d4-49cf-a245-9211b353c894/1AD7988C17663CC742B01BEF1A6DF2ED1741173009579AD50A94434E54F56073/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/71c6392f-8df5-4b61-8d50-dba6a525fb9d/510FC8C2112E2BC544FB29A72191EABCC68D3A5A7468D35D7694493BC8593A79/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/71c6392f-8df5-4b61-8d50-dba6a525fb9d/9378E04AE461E29CE5E46787D20F81700C80AD305B9417710D147C1D7FF0C970/VC_redist.arm64.exe
```

14.38.33130.0
```
https://download.visualstudio.microsoft.com/download/pr/f04bd1f4-d474-4dc1-bb63-5c059bb86c55/4DFE83C91124CD542F4222FE2C396CABEAC617BB6F59BDCBDF89FD6F0DF0A32F/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/f04bd1f4-d474-4dc1-bb63-5c059bb86c55/C61CEF97487536E766130FA8714DD1B4143F6738BFB71806018EEE1B5FE6F057/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/f04bd1f4-d474-4dc1-bb63-5c059bb86c55/BAC344CBC947DB8E306986BFB45A33052E1AAEE8F104ADBD9E461EB8199E27D2/VC_redist.arm64.exe
```

14.38.33126.1
```
https://download.visualstudio.microsoft.com/download/pr/cbd4fdf1-8ada-4370-9450-269186ad852f/1352880BC575E0565B2805285ACB09EB7A03357AE9FD1112DEEBF5B92C3D7EF2/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/cbd4fdf1-8ada-4370-9450-269186ad852f/4C1A888C8EBDCFB2F773CE658B713D3AA022C591977E0ED00D1E2C1F768572DA/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/cbd4fdf1-8ada-4370-9450-269186ad852f/D804A0047B982B00F661223D9956DD162C2E55059D81F6CC5DE2DE617313F922/VC_redist.arm64.exe
```

14.38.32919.0
```
https://download.visualstudio.microsoft.com/download/pr/02a6d5c5-3e10-47de-8025-d97a1321d3e3/5F60592799FAE0C82578112D4B621438FFC976AB39D848D8F7623F5705A83E27/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/02a6d5c5-3e10-47de-8025-d97a1321d3e3/AD573D3198853FC71137A88E51ABDE844B84F29B0CE6DD91BBEC661BC0143B36/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/9a901627-1c45-449c-8f19-98495982f202/395B4C8857D6AA47EED647B1361CC75751A92581060D1A1133CD4642269315B5/VC_redist.arm64.exe
```

14.36.32532.0
```
https://download.visualstudio.microsoft.com/download/pr/eaab1f82-787d-4fd7-8c73-f782341a0c63/917C37D816488545B70AFFD77D6E486E4DD27E2ECE63F6BBAAF486B178B2B888/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/eaab1f82-787d-4fd7-8c73-f782341a0c63/5365A927487945ECB040E143EA770ADBB296074ECE4021B1D14213BDE538C490/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/eaab1f82-787d-4fd7-8c73-f782341a0c63/37342E0ABDAEAE0297F64A889F842AC9453139639FB0178C0754A7D2F330043A/VC_redist.arm64.exe
```

14.36.32531.0
```
https://download.visualstudio.microsoft.com/download/pr/73d0ce7f-db4e-4687-a460-13ac8a3adf8d/1177BE7CAB68C385ED6C49216B975424C17E1D899C6F46A6197BDE90532AAA16/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/dc0441be-56f8-4a9a-b59b-2f251a8108e8/A44986BBB8519D78DD4C30C44878C0AF28643654082004BA3102789604AB23B1/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/dc0441be-56f8-4a9a-b59b-2f251a8108e8/7D19F1E22FCD1B17D36AF33B2D99CDD56E07FC3A6BAE3722198C709A638BE2B1/VC_redist.arm64.exe
```

14.36.32530.0
```
https://download.visualstudio.microsoft.com/download/pr/274f4243-aa00-418e-8718-692b15abdf1b/740C526E4910B1693D9BB02781F8AC2C49C821DCAE9173AAC90B7B5C6D1BC8EA/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/274f4243-aa00-418e-8718-692b15abdf1b/869F3F919653E8D9417416265C4D76D364A2257E8D3EE0197DBDF2E8525190F2/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/274f4243-aa00-418e-8718-692b15abdf1b/21C58CD2B71FC754E52AE11A48B07B3D12282DB588CFC1E102A43C68BE1CF874/VC_redist.arm64.exe
```

14.36.32522.0
```
https://download.visualstudio.microsoft.com/download/pr/4a2a0ce9-37ad-4697-9280-83111091da3e/BC21246E6B1F0B8570601492533490D8E35413840B59998D8B7AF9560F2DBB08/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/4a2a0ce9-37ad-4697-9280-83111091da3e/C50A5889D3B82D62EAD525FDE127A04F493A714C2EDCBF54B4088950B15D377F/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/4f354b21-bd4c-40b5-83a7-0baa12a63ebd/687CA8239E9055AD85EA2B1C7860D422374694157ABAAC8A43FAB4FFE69D865D/VC_redist.arm64.exe
```

14.36.32502.0
```
https://download.visualstudio.microsoft.com/download/pr/0891264a-2406-45ed-945e-229be35ed151/314D1ABAAAD2AAB2F98098066947142D9FFC6C4AE6EBC361F2BDF51FAE974949/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/8f11841e-9016-44c8-88b3-2aa7cc2cb6d7/BFD15CB36DE97C49183EE481E9E146D1282C9001D16AACE3868827C0C309AE8E/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/8f11841e-9016-44c8-88b3-2aa7cc2cb6d7/8BF30C6DF33165CD40CE3DD7642A1AFEF6CA55713D69534B7349AB6D3AE8FB3F/VC_redist.arm64.exe
```

14.36.32420.0
```
https://download.visualstudio.microsoft.com/download/pr/79d177d3-67a1-48e8-a684-dfa2ec50dd0b/EB7E51A53CA344208D93FBEE81E78C4A8D1F227B780A0C46B610870F99FF8E24/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/79d177d3-67a1-48e8-a684-dfa2ec50dd0b/405D28274D5053A520377639098AFB80C7DD4826701C1DABECCA7E028B19B8D1/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/79d177d3-67a1-48e8-a684-dfa2ec50dd0b/56E40B4BBE5E1F81A34EB0199562EE95DAC8639CE2C260FF4212BA5013D70296/VC_redist.arm64.exe
```

14.36.32323.0
```
https://download.visualstudio.microsoft.com/download/pr/6b9f2df7-b34b-413a-a832-b2fe819b2be6/8E73EAADD56ABEC0D4BBFD694470F75BBF3221DE02EA5B8C09EB0D3CCADAE1BC/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/4ab22709-f4f0-4b50-96ec-1164bfe1aa3e/98F01C0655933FE1A409775C1778CB71C120FA3529C5D091C7F6F7788E6B5049/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/6b9f2df7-b34b-413a-a832-b2fe819b2be6/4E0511FDFABB217A34C7352EAF85C31FC8ED9D0A3975293B3FB0ABC379A8788F/VC_redist.arm64.exe
```

14.34.31938.0
```
https://download.visualstudio.microsoft.com/download/pr/8b92f460-7e03-4c75-a139-e264a770758d/26C2C72FBA6438F5E29AF8EBC4826A1E424581B3C446F8C735361F1DB7BEFF72/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/cf0c2f70-6943-4973-81a1-b8d2685f1c75/8AE59D82845159DB3A70763F5CB1571E45EBF6A1ADFECC47574BA17B019483A0/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/cf0c2f70-6943-4973-81a1-b8d2685f1c75/EC530B52C87AF9DBECBCCE83E5945FD0CAA57969A858D7497E4D5CBBD6F53F60/VC_redist.arm64.exe
```

14.34.31931.0
```
https://download.visualstudio.microsoft.com/download/pr/bcb0cef1-f8cb-4311-8a5c-650a5b694eab/2257B3FBE3C7559DE8B31170155A433FAF5B83829E67C589D5674FF086B868B9/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/ea08a788-6381-4321-bc06-00199b5f9ed7/CE4843A946EE3732EB2BFC098DB5741DC5495C7BEA204E11D379336DCC68E875/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/bcb0cef1-f8cb-4311-8a5c-650a5b694eab/85759E1CA11B0DB71C9DC9D825ACC68AF0E6D74415A4D4BA5BAB2DEDEFB65628/VC_redist.arm64.exe
```

14.34.31921.1
```
https://download.visualstudio.microsoft.com/download/pr/f84eb94b-15bc-43e9-ada9-92068b7902ae/23E6C1322EAD18439C7CEAEE46B9E6A11999F800A103C16D9BD74C53A5934A51/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/f84eb94b-15bc-43e9-ada9-92068b7902ae/39EBE9EBC0FB5396603692A12D0D922E1918FCF2B0E6CC84FAF7B32079173501/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/dbe45ba9-8598-41fa-8aba-632e2329113a/BD589B1FB5FD34C2D1E3D282185ACAB3814D84CEAE8602FF502583EFB7B39CFC/VC_redist.arm64.exe
```

14.34.31823.3
```
https://download.visualstudio.microsoft.com/download/pr/a16e1596-7fef-4570-8d63-fb9d4e72c820/D0CAFF8097BB9C43A3685686826867506BF6EDD667F7B90092CB0EB1B964A85E/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/a16e1596-7fef-4570-8d63-fb9d4e72c820/BB66E74A41ECF5DC09487608E477ACC4F78A38A0EC4FFE3100069C8A067DA29A/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/90b6da66-cd08-444a-af98-b4f3f846526b/6547789411F466FA1EB030BAE3170AFA046EC9CD8E6E6A387D33E9CBB82FEC18/VC_redist.arm64.exe
```

14.32.31332.0 - **last version compatible with Windows Vista**
```
https://download.visualstudio.microsoft.com/download/pr/ed95ef9e-da02-4735-9064-bd1f7f69b6ed/CE6593A1520591E7DEA2B93FD03116E3FC3B3821A0525322B0A430FAA6B3C0B4/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/ed95ef9e-da02-4735-9064-bd1f7f69b6ed/CF92A10C62FFAB83B4A2168F5F9A05E5588023890B5C0CC7BA89ED71DA527B0F/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/ed95ef9e-da02-4735-9064-bd1f7f69b6ed/8E126191012691AE22A0D5A89FAC01B59BABC7B680E5D9B65828935FD366E375/VC_redist.arm64.exe
```

14.32.31326.0
```
https://download.visualstudio.microsoft.com/download/pr/6b6923b0-3045-4379-a96f-ef5506a65d5b/426A34C6F10EA8F7DA58A8C976B586AD84DD4BAB42A0CFDBE941F1763B7755E5/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/7ac2a695-28da-49db-8744-9e9ee2502f71/2ACBFE92157C1CF1A7B524A9325824046D83DBFA3FEB1CBD4DD02A42E020F77C/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/6b6923b0-3045-4379-a96f-ef5506a65d5b/6114C0A7A526EA47D9ADD78C718BEA0BA32EEF0826AA5610AF76877CC5FEB7F3/VC_redist.arm64.exe
```

14.32.31302.0
```
https://download.visualstudio.microsoft.com/download/pr/f359701c-0fda-414e-83c2-31d65ee7f308/4B2947448BF80CC987A440B43A1AA07152B9057915C68930061C74E0B40BA05B/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/79465679-7995-4f6c-984b-33de61668fe4/37E08B5D6EDC325ACD805AD35CEE6506ADAF88ACCC7086BE2E771E69400AADE8/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/79465679-7995-4f6c-984b-33de61668fe4/198D232C7BCCBA78D809BA0F935F7135471241B87A49E4A5FE668B10857CAB57/VC_redist.arm64.exe
```

14.31.31103.0
```
https://download.visualstudio.microsoft.com/download/pr/d22ecb93-6eab-4ce1-89f3-97a816c55f04/37ED59A66699C0E5A7EBEEF7352D7C1C2ED5EDE7212950A1B0A8EE289AF4A95B/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/8e32d7eb-5130-4dc8-9c3e-5891f375e112/B7AE307237F869E09F7413691A2CD1944357B5CEE28049C0A0D3430B47BB3EDC/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/d22ecb93-6eab-4ce1-89f3-97a816c55f04/4671015C191EF3FD276ECE18BD7A5C6D9BFB7BF475ED6526605C82234BEEA581/VC_redist.arm64.exe
```

14.31.31005.0
```
https://download.visualstudio.microsoft.com/download/pr/36270b27-6b33-460f-b309-72fe8ad2e9c1/C3261464D8EA58988BCD946AFD4C82DC64405335C4E9BA75402837AED32F3EFC/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/36270b27-6b33-460f-b309-72fe8ad2e9c1/C160CF4F7405B3AE263A46EC87445F3E851CD64389AEF4A2C2D9029127DF40D5/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/36270b27-6b33-460f-b309-72fe8ad2e9c1/3DA669399E508181E9CAEDC90A6C2A35B202590C86DC9F088476FF8C1A18E757/VC_redist.arm64.exe
```

14.31.30919.0
```
https://download.visualstudio.microsoft.com/download/pr/8c1c2dbb-0856-4dc3-b863-b16c637bc245/C527CE426B8D25CB7D4F577476E984C73E84AAAC3E84730BC118A4E0E0FA3CB0/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/8c1c2dbb-0856-4dc3-b863-b16c637bc245/E55681B9E07A58F7143E5AB5941F45DE0B485E0C9933B0CB6B702D3921F48527/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/8c1c2dbb-0856-4dc3-b863-b16c637bc245/8DDCE24CF44750E2E8230725CD99150671F08DB30C1A515272BC39BB3FEE6829/VC_redist.arm64.exe
```

14.31.30818.0
```
https://download.visualstudio.microsoft.com/download/pr/ad322fe0-1435-4fa2-9ea4-c6208b41e7d8/66E0B36ACE18FFFF26EC93035CD1D16DA7294D1A9179FC494F1A6DA3F1AE5183/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/d139d1c2-d4a4-4c00-8696-1bb5fdb2827d/C15D42AB8FF9816782869B6F7C50A8D6C542EF9E555E6EA500CE9C3C09CF8138/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/ad322fe0-1435-4fa2-9ea4-c6208b41e7d8/03246F053B35FDCA96A393E217042BC369FCB2760ED5485A878BAB70DD763888/VC_redist.arm64.exe
```

14.30.30708.0
```
https://download.visualstudio.microsoft.com/download/pr/571ad766-28d1-4028-9063-0fa32401e78f/5D3D8C6779750F92F3726C70E92F0F8BF92D3AE2ABD43BA28C6306466DE8A144/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/571ad766-28d1-4028-9063-0fa32401e78f/F02DEA65EA65633D1718E6C5E5EEE7D2DF640D1FFF332E4669DEA530B8C4F0E7/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/571ad766-28d1-4028-9063-0fa32401e78f/E82B93D19330234DA9990744FFE70750A6D154F2D2B17376BFD18747749E236E/VC_redist.arm64.exe
```

14.30.30704.0
```
https://download.visualstudio.microsoft.com/download/pr/c627417f-7c6d-44a6-86c3-95c1acbbd5f5/A9F5D2EAF67BF0DB0178B6552A71C523C707DF0E2CC66C06BFBC08BDC53387E7/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/c627417f-7c6d-44a6-86c3-95c1acbbd5f5/AC75A82D873E6B6F98B1D293042380764D7D263C43438E50D564FA58C9F891C2/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/c627417f-7c6d-44a6-86c3-95c1acbbd5f5/F6A246EAB3346912F0D308BBFE3A2CD9A42F47CD43584A993AF9388CFB8B6617/VC_redist.arm64.exe
```

14.30.30528.0
```
https://download.visualstudio.microsoft.com/download/pr/3b11b293-efb3-4d32-9024-c86df077dd3b/36D098A6AEB72956F8FC6A1ABF868E5831FBD1EFF5A4AD1D98DDD6A9E563FF84/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/6f129eea-cdb4-4a2c-aeb2-7509b1823406/4EEDED018D1A67BBD602CADC6A6528AF6FFF302DAD0FB7D75B3694DA85A9DCC4/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/3b11b293-efb3-4d32-9024-c86df077dd3b/0051DA0A24173CD1A6E5AD0D9542339859FDD85C3E15F64EAFB5C8AFE96DCC53/VC_redist.arm64.exe
```

14.30.30423.0
```
https://download.visualstudio.microsoft.com/download/pr/fc92a69f-aa16-4f81-afbc-bfbd2613a119/597D784B9EDD3E342CAB173436A814AF15C42B16EFC6F631A369C4FC06F6E0F9/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/a9bffe0a-c7c6-4067-8d77-bb33c305bf24/CFE4531606ABC1644DB8D86F0D5B6FD3EC1DDF6382E8E74463CE2346942322CC/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/a9bffe0a-c7c6-4067-8d77-bb33c305bf24/C5746722195FA7C928998E8D607577C36CB65B4E0E6C5B4A520FFC094FF32832/VC_redist.arm64.exe
```

14.30.30401.0
```
https://download.visualstudio.microsoft.com/download/pr/8ed43637-a368-42e7-92ff-a4f6085b71ee/7D6F51D1615639B5634E49335BBE14B8A09074EDEA4599B9732AF94D9188A22A/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/e319625d-64bc-4861-9c13-3e3dd748796f/3391CD4D30D87E088BA976E71588CB52AF23CB93CFDB19F39704D622347A6FCD/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/8ed43637-a368-42e7-92ff-a4f6085b71ee/C16781689B540728A91C1024DEA6FFDDC230B0354AAC1BECF41C5EC7BE472700/VC_redist.arm64.exe
```
</details>

______________________________

<details><summary>2019</summary>


14.29.30153.0
```
https://download.visualstudio.microsoft.com/download/pr/9613cb5b-2786-49cd-8d90-73abd90aa50a/CEE28F29F904524B7F645BCEC3DFDFE38F8269B001144CD909F5D9232890D33B/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/9613cb5b-2786-49cd-8d90-73abd90aa50a/29F649C08928B31E6BB11D449626DA14B5E99B5303FE2B68AFA63732EF29C946/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/9613cb5b-2786-49cd-8d90-73abd90aa50a/F5B61B462E4D0227DC3FECA416EA696F837F1574229C0CCE92C45FA5DD365834/VC_redist.arm64.exe
```

14.29.30139.0
```
https://download.visualstudio.microsoft.com/download/pr/b929b7fe-5c89-4553-9abe-6324631dcc3a/296F96CD102250636BCD23AB6E6CF70935337B1BBB3507FE8521D8D9CFAA932F/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/b929b7fe-5c89-4553-9abe-6324631dcc3a/4C6C420CF4CBF2C9C9ED476E96580AE92A97B2822C21329A2E49E8439AC5AD30/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/b929b7fe-5c89-4553-9abe-6324631dcc3a/71F6D2FAB64D23ADE47350555351FFE93E5AA06046C7DFEDB793308B46DF7845/VC_redist.arm64.exe
```

14.29.30135.0
```
https://download.visualstudio.microsoft.com/download/pr/e332b62b-e04e-4cbd-8c3b-41bc13761c41/9B9DD72C27AB1DB081DE56BB7B73BEE9A00F60D14ED8E6FDE45DAB3E619B5F04/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/73b58d04-0049-47d1-9f54-1784792c71cd/80C7969F4E05002A0CD820B746E0ACB7406D4B85E52EF096707315B390927824/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/73b58d04-0049-47d1-9f54-1784792c71cd/17EE7CC0974BADB0EBD96C1F55B041EB361E9AED7904D08BC1D5F743B195001F/VC_redist.arm64.exe
```

14.29.30134.0
```
https://download.visualstudio.microsoft.com/download/pr/6da35dbc-3b1d-4e88-a951-3154fcc00546/FB53A73818CB8B7DB84C5E8CA0455694CA9FAD67213B4603CD210808FA5982FE/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/04afd737-6b6d-4d75-99cf-ff069468fdf8/729E7D500D58880C24C9F3E09B269319957DE93C9A2238D092B57A6CFD336045/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/04afd737-6b6d-4d75-99cf-ff069468fdf8/85DBBA78E84D28885360B64DEDC780C3E11F65AB68018B47A2B056690C545728/VC_redist.arm64.exe
```

14.29.30133.0
```
https://download.visualstudio.microsoft.com/download/pr/7239cdc3-bd73-4f27-9943-22de059a6267/003063723B2131DA23F40E2063FB79867BAE275F7B5C099DBD1792E25845872B/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/9c65ee54-a03f-4683-aa26-d17d174069f8/1ACD8D5EA1CDC3EB2EB4C87BE3AB28722D0825C15449E5C9CEEF95D897DE52FA/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/7239cdc3-bd73-4f27-9943-22de059a6267/15F433A52E6A533E48675CA92B94674BC519FFFB550D344B1F091FD199A80294/VC_redist.arm64.exe
```

14.29.30130.2
```
https://download.visualstudio.microsoft.com/download/pr/d8d2c767-70f7-45fa-8457-be8ed7a34797/1C1501B8EE4FBD0D5C08B9E80699E49E98C6139E2C745B2EB01284380309A310/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/d8d2c767-70f7-45fa-8457-be8ed7a34797/C38254620ABBB32552003821CA181EF934A42F11B442F13B9C3BA3922316A60F/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/d8d2c767-70f7-45fa-8457-be8ed7a34797/DF1E3BDD68F42B9FF0AB21CB09531F166EA4F8B00DA7A90EBB0B4DB7749E485A/VC_redist.arm64.exe
https://download.visualstudio.microsoft.com/download/pr/4887aefb-2064-4e76-b634-68af56a3d336/1C1501B8EE4FBD0D5C08B9E80699E49E98C6139E2C745B2EB01284380309A310/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/4887aefb-2064-4e76-b634-68af56a3d336/C38254620ABBB32552003821CA181EF934A42F11B442F13B9C3BA3922316A60F/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/4887aefb-2064-4e76-b634-68af56a3d336/DF1E3BDD68F42B9FF0AB21CB09531F166EA4F8B00DA7A90EBB0B4DB7749E485A/VC_redist.arm64.exe
https://download.visualstudio.microsoft.com/download/pr/d4f71795-e1c4-4a15-a116-b2dc8e18c6ab/1C1501B8EE4FBD0D5C08B9E80699E49E98C6139E2C745B2EB01284380309A310/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/d4f71795-e1c4-4a15-a116-b2dc8e18c6ab/C38254620ABBB32552003821CA181EF934A42F11B442F13B9C3BA3922316A60F/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/d4f71795-e1c4-4a15-a116-b2dc8e18c6ab/DF1E3BDD68F42B9FF0AB21CB09531F166EA4F8B00DA7A90EBB0B4DB7749E485A/VC_redist.arm64.exe
https://download.visualstudio.microsoft.com/download/pr/6a65c421-1318-4695-a7a2-5f6fe4db26a6/1C1501B8EE4FBD0D5C08B9E80699E49E98C6139E2C745B2EB01284380309A310/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/6a65c421-1318-4695-a7a2-5f6fe4db26a6/C38254620ABBB32552003821CA181EF934A42F11B442F13B9C3BA3922316A60F/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/6a65c421-1318-4695-a7a2-5f6fe4db26a6/DF1E3BDD68F42B9FF0AB21CB09531F166EA4F8B00DA7A90EBB0B4DB7749E485A/VC_redist.arm64.exe
https://download.visualstudio.microsoft.com/download/pr/9050f884-aca2-4dd8-9772-94d31c3e89e0/1C1501B8EE4FBD0D5C08B9E80699E49E98C6139E2C745B2EB01284380309A310/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/9050f884-aca2-4dd8-9772-94d31c3e89e0/C38254620ABBB32552003821CA181EF934A42F11B442F13B9C3BA3922316A60F/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/9050f884-aca2-4dd8-9772-94d31c3e89e0/DF1E3BDD68F42B9FF0AB21CB09531F166EA4F8B00DA7A90EBB0B4DB7749E485A/VC_redist.arm64.exe
```

14.29.30129.3
```
https://download.visualstudio.microsoft.com/download/pr/d69d858e-0f8f-4c16-a38f-365d1c3930e5/3CF1F7A29C6111CFD06294A473B3B5276801DA4AB18AA215CAA3F7A996145FA7/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/1b28b620-3102-4db4-bce4-d890b9b35596/126CC1D4A5EE72EE6E2EAFA1CA9AACD6196D7A87B675F3E5E4F5AEAF5B2954A4/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/d69d858e-0f8f-4c16-a38f-365d1c3930e5/DE541A47D1DED1A93454022FF29CF14249FABD497C0567615B77C5DF95E300A2/VC_redist.arm64.exe
```

14.29.30129.1
```
https://download.visualstudio.microsoft.com/download/pr/ea091104-d377-43ed-9fe9-7ef21137e1fb/36F6A5DB117FB5877839FAFF89ABBE03C277620C24719700CFD0A063B02A1446/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/9bc0b76f-ce24-4207-9dd4-5f1dc47da1d6/A8401D39E8A2F6CAA3FF9A93591ADD7B8A04526C1472C4F6D4DBBC26A2614387/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/432cecc3-0564-4844-b029-25989c5de206/ADD2E4ACB75D94B570F6D53B7581FB0B5310B71F8023D119857A452416B1B62C/VC_redist.arm64.exe
```

14.29.30040.0
```
https://download.visualstudio.microsoft.com/download/pr/36e45907-8554-4390-ba70-9f6306924167/97CC5066EB3C7246CF89B735AE0F5A5304A7EE33DC087D65D9DFF3A1A73FE803/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/888b4c07-c602-499a-9efb-411188496ce7/F3A86393234099BEDD558FD35AB538A6E4D9D4F99AD5ADFA13F603D4FF8A42DC/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/888b4c07-c602-499a-9efb-411188496ce7/B76EF09CD8B114148EADDDFC6846EF178E6B7797F590191E22CEE29A20B51692/VC_redist.arm64.exe
```

14.29.30039.3
```
https://download.visualstudio.microsoft.com/download/pr/663a4343-1b03-421c-ae7c-620d23e67e4b/DB7FD8373043715BA3C13EE82AADE042352CFCB24CBEA05B8EB90CB5AA7AF768/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/663a4343-1b03-421c-ae7c-620d23e67e4b/8E174C21FF89025A284B0E98DCD5C8F72A828C7E56FF2D00B34EA5E38F6FB389/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/663a4343-1b03-421c-ae7c-620d23e67e4b/7C424492FE440E2A32BA7E75A68F59B4F2135C2CE7BDB68B1BE3151A019EF12D/VC_redist.arm64.exe
```

14.29.30038.0
```
https://download.visualstudio.microsoft.com/download/pr/dbee0eea-0787-43e1-a27c-96d8278d957b/A1A21B77FABF51E1F07346A852FBE27C1E172368E735FCC749DE82725A09CB71/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/154fcca0-30cc-42d6-9b47-1d3041b1b921/74A7A5E01BBE524353ABF2D7C133ACF92EA4820D54FBF29EB4E881D8885C3D31/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/dbee0eea-0787-43e1-a27c-96d8278d957b/C35E177E7E19415CF22CEE316FB81E9CAE4B4388E1317C1602B5CF69CC6D9A3D/VC_redist.arm64.exe
```

14.29.30037.0
```
https://download.visualstudio.microsoft.com/download/pr/bdfb22a4-b1ee-48ab-9b43-70dc88e60347/A1592D3DA2B27230C087A3B069409C1E82C2664B0D4C3B511701624702B2E2A3/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/76a91598-ca94-410b-b874-c7fa26e400da/91C21C93A88DD82E8AE429534DACBC7A4885198361EAE18D82920C714E328CF9/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/bdfb22a4-b1ee-48ab-9b43-70dc88e60347/AD905A6DFD125CFB38472A1B0BA791AEA1A6C8256392093D65F6268AAFD37ED8/VC_redist.arm64.exe
```

14.29.30036.3
```
https://download.visualstudio.microsoft.com/download/pr/ab214313-abce-4e01-8012-0a2aa31d7734/8C62C111E1737FEBF0640918BBD55BD147EF7D6652F2D898804BDC87595C9E01/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/ab214313-abce-4e01-8012-0a2aa31d7734/6DD2990667C78F8962A11F41DF42912EA5F1C7B9FB73BEA363FA5D05023633F3/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/ab214313-abce-4e01-8012-0a2aa31d7734/AA9A64C58DC6A0828ECCCDE334E3B1BE1C70D6E834C3E4BCDB3E7AD0158AAC89/VC_redist.arm64.exe
```

14.29.30035.0
```
https://download.visualstudio.microsoft.com/download/pr/3ce3714c-165a-42ba-94f0-97ede790bbbd/983389F4D7C874DCB3D2C4337CC07F111F4E1D23DEDEFCCBEF8D296F260F623C/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/3ce3714c-165a-42ba-94f0-97ede790bbbd/29D4839EA2843D9C69DA2CBE44DC8FD9CCFA5BD7BA9EB4E006EC232413E5468E/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/f0c36734-5ab0-4dc1-b6b8-5a9023335572/8EAC3C9DD165553119066C04128304C4CCD1179C6BBF6E273A7126B8D00632BF/VC_redist.arm64.exe
```

14.29.30034.3
```
https://download.visualstudio.microsoft.com/download/pr/356ea9c9-ef22-443a-90e1-0d51c9752f04/21E179D5DFC8B3F28FEA90F5B5FD7E070BAE714D98A50759DEFD04922A6C18F1/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/483f9e2c-b56f-45ab-ae40-2a98c5f7a701/7C5F76E70608BCF384BE577397B09E3CBB784607FF37D38551543EF564EA624D/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/483f9e2c-b56f-45ab-ae40-2a98c5f7a701/8B197118CAAE7657F564FE0A21BF9DD5B8104F536ECCBD68D9CFBFA4EB3A5061/VC_redist.arm64.exe
```

14.29.30032.0
```
https://download.visualstudio.microsoft.com/download/pr/85f76fda-9ac8-457e-8ed9-f2dd6415464a/7B1BCC31157882835ED6B576EE43738F127BFD6FB1BA8BD292DAF32388D3A20D/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/85f76fda-9ac8-457e-8ed9-f2dd6415464a/8FC7C0A46495F7A9C24B9ED840B5509D08FE12D3F7652FE469F341B564646C05/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/85f76fda-9ac8-457e-8ed9-f2dd6415464a/C79AFC30650FF9F6158EE6DF1FEC0B704CD2A4A69D3FA21BFA321B860E81ECEB/VC_redist.arm64.exe
```

14.29.30031.0
```
https://download.visualstudio.microsoft.com/download/pr/319c0957-2c9f-44b9-9a40-9511a06acda2/84D968AF8984532A4263D1E09808175794EB27ABE90BCF518DD4F35F84DBB65C/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/a59bd032-813f-4f57-9f01-c7eae0225894/BBF0FF79C8CFF26C68AD960E09854F2CC19417F7F0C59F95A9B077E3B4DE2A85/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/a59bd032-813f-4f57-9f01-c7eae0225894/1B570D25A8C982911041ACA89FB139C5B62CE628D7BB412AD641BCDED866CB9B/VC_redist.arm64.exe
```

14.29.30030.0
```
https://download.visualstudio.microsoft.com/download/pr/8848a076-abd9-4f93-b981-aaca5c41577e/F0F192C83B44626B2760EDC79248C09C4FF5F73F66F1D243B6A93F8715F723EB/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/8848a076-abd9-4f93-b981-aaca5c41577e/39664849DED638283FE48E456EB93D0F3294DE445100151AF0C5DEAF3C2EB348/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/8848a076-abd9-4f93-b981-aaca5c41577e/5334395AA434C69645175EFC9A48DFD4E973A49CD7A65045E4CEC8541064D672/VC_redist.arm64.exe
```

14.29.30024.0
```
https://download.visualstudio.microsoft.com/download/pr/379431f5-ab7c-4c88-b58e-5a17184881a5/50A4B93C2FC33FD09F0F171A8D2E8231B4F641979B77D30137229205BA2EA854/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/379431f5-ab7c-4c88-b58e-5a17184881a5/D57C752BAE4CB387DF0BCA606AAE2FC815608B2257B11AA2236DD346F70E57DE/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/379431f5-ab7c-4c88-b58e-5a17184881a5/BC4F1B0984546BC93CD31BB1948936775D7A30B17AC9776F198B61C9A1A98793/VC_redist.arm64.exe
```

14.28.29918.0
```
https://download.visualstudio.microsoft.com/download/pr/507546ad-70db-490b-b218-4797eadaf29e/7D469B1638E1476B50609DB140B17DAD9EA7AAA60C75C5143A076194DA770057/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/837e6eb3-c125-4658-8e1b-3805aae790eb/791426878CEEBFF91AB9F6339EE69AA604DB691035F79EFF68C0F4C68C6B9B77/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/507546ad-70db-490b-b218-4797eadaf29e/D600266D48AB96AEE6FBFF92A89F0204551E251FB186ABCE5DC1808D280379FC/VC_redist.arm64.exe
```

14.29.29917.0
```
https://download.visualstudio.microsoft.com/download/pr/b9e165b0-55b9-470c-b365-062ed97bb651/D257A6A1F53F9CDF1CE7B347B1C68AD25465D7F780BACF3363FC627A8EE5068D/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/b9e165b0-55b9-470c-b365-062ed97bb651/ACAD146A8CFC3ABE4170334889B6EC34470F7DF54F18CA701AA430000B9CA955/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/b9e165b0-55b9-470c-b365-062ed97bb651/5DD55B59B44E891A6583437E3F9140816BBF8DFC3B85EA0B90DEAC80AEF6A18C/VC_redist.arm64.exe
```

14.28.29914.0
```
https://download.visualstudio.microsoft.com/download/pr/85d47aa9-69ae-4162-8300-e6b7e4bf3cf3/52B196BBE9016488C735E7B41805B651261FFA5D7AA86EB6A1D0095BE83687B2/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/85d47aa9-69ae-4162-8300-e6b7e4bf3cf3/14563755AC24A874241935EF2C22C5FCE973ACB001F99E524145113B2DC638C1/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/02f33c07-3e2e-4812-8477-f9be45a7cd63/D8A52C49AE94150656DA4F87AED39FB7A4429AFB4F1050EB59F8625074D72BD4/VC_redist.arm64.exe
```

14.28.29913.0
```
https://download.visualstudio.microsoft.com/download/pr/366c0fb9-fe05-4b58-949a-5bc36e50e370/015EDD4E5D36E053B23A01ADB77A2B12444D3FB6ECCEFE23E3A8CD6388616A16/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/366c0fb9-fe05-4b58-949a-5bc36e50e370/E830C313AA99656748F9D2ED582C28101EAAF75F5377E3FB104C761BF3F808B2/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/366c0fb9-fe05-4b58-949a-5bc36e50e370/9C1E5D2F134EE64D9ED5E3C3F7DD6B5B61931B0C4613A0D0A0BB67EBFB6C3F1B/VC_redist.arm64.exe
```

14.28.29910.0
```
https://download.visualstudio.microsoft.com/download/pr/13ba5434-06d8-4e48-ae76-1bdf2ac62472/F299953673DE262FEFAD9DD19BFBE6A5725A03AE733BEBFEC856F1306F79C9F7/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/d64b93c3-f270-4750-9e75-bc12b2e899fb/4521ED84B9B1679A706E719423D54EF5E413DC50DDE1CF362232D7359D7E89C4/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/13ba5434-06d8-4e48-ae76-1bdf2ac62472/D49B964641B8B2B9908A2908851A6196734B47BCC7B198C387287C438C8100B7/VC_redist.arm64.exe
```

14.28.29812.0
```
https://download.visualstudio.microsoft.com/download/pr/b29e54d1-216d-423a-8160-742b2ec94cc1/FA3E2A414D47D2C9691719795E5A3C66E515D0FFF9C3144D7DDBDFD0351F74DB/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/b29e54d1-216d-423a-8160-742b2ec94cc1/4B39A47E4C71BE4F43F1616B4C92092ABC932214DEAAD1E983602DCE1CA820DF/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/22ba7971-e7be-452e-93bb-e9ee62f83e51/197BAF54EF05397771905D3E483D670279FAF999729CFEEF6765BA97EB69194E/VC_redist.arm64.exe
```

14.28.29805.2
```
https://download.visualstudio.microsoft.com/download/pr/09a4d98a-776b-46df-9f44-91fe5d832b03/860FA3BC9E85F877BCFCBB2FFAB271D5B4C7D4BA4D85E3F5C3625596D2836412/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/09a4d98a-776b-46df-9f44-91fe5d832b03/7A1418302833E53014EDD7C6C13A61CDB3AF472D252776DAA3B6D773B057FDC3/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/09a4d98a-776b-46df-9f44-91fe5d832b03/F4B92F8D0D0410E0382BFC83A8CFA3B28D207E32BE8F29BF6338A289EF7758F8/VC_redist.arm64.exe
```


14.28.29715.1
```
https://download.visualstudio.microsoft.com/download/pr/7f220946-40a5-4478-be8f-ffb38fbdc485/7B8A8AAF09DF235B0E7010C66A0F71BE796E052FDC8A36B6950A9CB76C540C23/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/7f220946-40a5-4478-be8f-ffb38fbdc485/AB233EA4C28D73DD6F2CBA125B7934A734A851DA7D4E21AEFA508F650AE330D8/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/7f220946-40a5-4478-be8f-ffb38fbdc485/D1D41A1B63FCF767F78560C982C230E4C2D3CAE0D54EF13CD5D183DAA7889179/VC_redist.arm64.exe
```

14.28.29617.0
```
https://download.visualstudio.microsoft.com/download/pr/1415835d-76a5-42c8-9aeb-baa77ae9f964/D0290C14D84DD077D443CD9E51C8E5A1443AA3363F06A2BA84D1FDE4637441EE/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/1415835d-76a5-42c8-9aeb-baa77ae9f964/9F0B39C6C9E957C15604C8356549B0830B2241A45FD9852DEFED39B4E35DE27E/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/1415835d-76a5-42c8-9aeb-baa77ae9f964/7BE33ED972CB5488CF7DD03422AC780DE8619A03C7E05808669AE82F6E4045E4/VC_redist.arm64.exe
```

14.28.29515.1
```
https://download.visualstudio.microsoft.com/download/pr/4156fe47-ddaf-4a98-90c0-cf3f76f598b0/464FCFCF45BC9DDFB866BEC070A5F0D638AA596CDC1897BCE5D7C06239EB6F98/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/a0375c32-aa07-42ac-9f2f-78745dcd4ae1/8E7699DDAD05E2BAB1E52E2D334CA46352F446FF38DE47CE65C3B4F4185D9177/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/4156fe47-ddaf-4a98-90c0-cf3f76f598b0/669538AF642667488DB97FDB26A998C30BFA46E48CB4BB32D137EDC9B610939A/VC_redist.arm64.exe
```

14.28.29334.0
```
https://download.visualstudio.microsoft.com/download/pr/199689a5-9b72-41ca-8c9e-4323178e780d/C2D74D9B85D0030EAA134679A2392268BAA773185C5A21657390E43F8B518F69/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/199689a5-9b72-41ca-8c9e-4323178e780d/5C7DFA4FD52809813CF9350C4E5807434D78A0BB1FD0D61C85E02B41646A5780/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/199689a5-9b72-41ca-8c9e-4323178e780d/5DCF9F06F0A1036B3283B5277EB8B26FC4C503301A81669A21A8DE93CCED5AD0/VC_redist.arm64.exe
```

14.28.29325.2
```
https://download.visualstudio.microsoft.com/download/pr/7651ff4e-1916-49be-9e7d-e92ebc183adf/B1A32C71A6B7D5978904FB223763263EA5A7EB23B2C44A0D60E90D234AD99178/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/8ecb9800-52fd-432d-83ee-d6e037e96cc2/50A3E92ADE4C2D8F310A2812D46322459104039B9DEADBD7FDD483B5C697C0C8/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/7651ff4e-1916-49be-9e7d-e92ebc183adf/E52B9AFDF99C3802BF6F48269B212B08468742D50DABDCDFB1E6409189ADBABE/VC_redist.arm64.exe
```

14.28.29301.0
```
https://download.visualstudio.microsoft.com/download/pr/759117aa-c0dd-4a27-b7e0-b55a79015774/1ED5EF7B558C89E24F76788A48CB516239C43D1518CD108AC00BF5503333C373/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/759117aa-c0dd-4a27-b7e0-b55a79015774/E2DC48379BD2D2506A15D10F0631A96AD0E2B7D9DB326D5B21BB63D26A087C73/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/517612cb-7f85-456d-8b41-b2a776ecedd6/2303BAC96A3763DC3C3AB7984F01A62218A10C3AA455A6663B20CF643CA9B57D/VC_redist.arm64.exe
```

14.28.29231.0
```
https://download.visualstudio.microsoft.com/download/pr/a23ce03b-5941-42cd-8d3f-9d08296c319f/026850EB3B7A1CBF254B6AFDB9EA9EF1172251883FE79491D5B839AC77B59882/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/49eb0868-9b72-47af-a707-d34b004b2751/1E5D1DEA8C582B4BA3BE56199A472C58483252D0BAABF1E61287F8978A6160CD/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/a23ce03b-5941-42cd-8d3f-9d08296c319f/13FCD8BF1E138BB748E8D7FB868C5E79BBFB6D1F7FE92025DB0029DE58E24B91/VC_redist.arm64.exe
```

14.28.29213.0 - **last version compatible with Windows XP**
```
https://download.visualstudio.microsoft.com/download/pr/566435ac-4e1c-434b-b93f-aecc71e8cffc/B75590149FA14B37997C35724BC93776F67E08BFF9BD5A69FACBF41B3846D084/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/566435ac-4e1c-434b-b93f-aecc71e8cffc/0D59EC7FDBF05DE813736BF875CEA5C894FFF4769F60E32E87BD48406BBF0A3A/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/7b0dbd13-8740-4bcd-b86e-dffe0002c0b2/07C0219A8002491F85604EB76AADBD11DB819AF8A813621376B5DA5630C21E20/VC_redist.arm64.exe
```

14.28.29115.0
```
https://download.visualstudio.microsoft.com/download/pr/28bd19d3-af87-4c4e-859f-8a656db29219/9838775699DFCEFC83BD8B6FE9862E16A12E0CD3C707B7DBA6FF83388D90C488/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/6b03c53c-e1f7-4ac0-8e82-a771ef1d6374/7E491DDBCD2DCC25B6038994372A7EE8E15B8771519A09879E2317C35542EB50/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/28bd19d3-af87-4c4e-859f-8a656db29219/2864526FAE9AEECE0A877E50B169A188A029058B21A64F5F27429B5D03AD0010/VC_redist.arm64.exe
```

14.27.29114.0
```
https://download.visualstudio.microsoft.com/download/pr/722d59e4-0671-477e-b9b1-b8da7d4bd60b/591CBE3A269AFBCC025681B968A29CD191DF3C6204712CBDC9BA1CB632BA6068/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/56f631e5-4252-4f28-8ecc-257c7bf412b8/D305BAA965C9CD1B44EBCD53635EE9ECC6D85B54210E2764C8836F4E9DEFA345/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/722d59e4-0671-477e-b9b1-b8da7d4bd60b/5205C0FA2A105268AAB6BD37D0BD06A678E29579B81140E76433035EDA49CEAD/VC_redist.arm64.exe
```

14.27.29112.0
```
https://download.visualstudio.microsoft.com/download/pr/c61fa35d-a027-4901-aa8e-9993ae4f4fbe/4B5890EB1AEFDF8DFA3234B5032147EB90F050C5758A80901B201AE969780107/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/c61fa35d-a027-4901-aa8e-9993ae4f4fbe/CAA38FD474164A38AB47AC1755C8CCCA5CCFACFA9A874F62609E6439924E87EC/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/c61fa35d-a027-4901-aa8e-9993ae4f4fbe/A950A1C9DB37E2F784ABA98D484A4E0F77E58ED7CB57727672F9DC321015469E/VC_redist.arm64.exe
```

14.27.29016.0
```
https://download.visualstudio.microsoft.com/download/pr/fd5d2eea-32b8-4814-b55e-28c83dd72d9c/952A0C6CB4A3DD14C3666EF05BB1982C5FF7F87B7103C2BA896354F00651E358/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/cf2cc5ea-1976-4451-b226-e86508914f0f/B4D433E2F66B30B478C0D080CCD5217CA2A963C16E90CAF10B1E0592B7D8D519/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/fd5d2eea-32b8-4814-b55e-28c83dd72d9c/95D3E19C9BDE8F0E8C0C73BF539CD2C62598498436FA896B864ECB8E3B70BD17/VC_redist.arm64.exe
```

14.27.29009.1
```
https://download.visualstudio.microsoft.com/download/pr/0d8fc2c5-919f-49bd-b00b-f4287e69dc96/2712CD6D28DBC14877C365D71CAFCF22E028A7541CF285B6D0046BE629B54D36/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/d4ded7c7-97d2-43c1-a630-718d1e19f7db/B0220F4CC99D32A730B96D69A76A184AAFF964EA3AE337C7C275BA8F1674E13F/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/0d8fc2c5-919f-49bd-b00b-f4287e69dc96/42F5B6A7F7626ED8AD01E8E1970381731C6A954B90115DF02A0FC30964FB4340/VC_redist.arm64.exe
```

14.27.28914.0
```
https://download.visualstudio.microsoft.com/download/pr/3b401cc2-5336-4198-9ede-11fad5e04f1b/EF6DDAAE708E022335040D63B00F81B90429EDE491BDD48CAC7D64FBBFC0A62B/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/3b401cc2-5336-4198-9ede-11fad5e04f1b/0FC41D73B206889C48C0929AF60DA35695C1EA6394C5F37ADD212F212F9FED64/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/3b401cc2-5336-4198-9ede-11fad5e04f1b/1BE0C4DC792B82C0F8215BD80387487FCF68455B44ABAF27846BD9A3052F0854/VC_redist.arm64.exe
```

14.27.28823.0
```
https://download.visualstudio.microsoft.com/download/pr/59b4ca04-67d2-4cd4-bb9e-1373e4539e95/4701B841EBE9BD5DA0AEAD0207982BBD3E84A3D028B69DF0E87B4F5B7B683BBB/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/59b4ca04-67d2-4cd4-bb9e-1373e4539e95/47CEFFE0CB8FD62D0EFA2A79FE18B69148CFB6549B96114278B18D6E16809FD9/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/59b4ca04-67d2-4cd4-bb9e-1373e4539e95/10A159D736D48F7B84184B9B0A32B6C43B19B4ABF43EE2D10FA025A4A2FA6668/VC_redist.arm64.exe
```

14.26.28808.1
```
https://download.visualstudio.microsoft.com/download/pr/fba519f2-0344-4b8c-9ced-ed72999dadf3/0FB665AD7CB22984772B144D8E565CDBF65459BA9874D4D102ADACE7C4A89BC8/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/ee3709ed-77df-4b0b-8abf-4da300ef811d/44839D5E96C334EC387F386FC92C22CAE23AB5B8F1613CB9392D210A2E7E9A50/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/6054a747-d3f3-4851-86b8-c005c9633eb3/C1AFCAC3DBB1C972FC5F9B408D1C8435781FE5BA91B11E7DBE2F325AA17969CB/VC_redist.arm64.exe
```

14.26.28720.3
```
https://download.visualstudio.microsoft.com/download/pr/bb3a2acf-b47b-4a7b-9aaa-8ad356ccb62b/7D7105C52FCD6766BEEE1AE162AA81E278686122C1E44890712326634D0B055E/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/bb3a2acf-b47b-4a7b-9aaa-8ad356ccb62b/A06AAC66734A618AB33C1522920654DDFC44FC13CAFAA0F0AB85B199C3D51DC0/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/bb3a2acf-b47b-4a7b-9aaa-8ad356ccb62b/F7850888E7F1A801607D760D7D78B4357C85AE4CE397B9A6626FAE0CF773385A/VC_redist.arm64.exe
```

14.26.28619.0
```
https://download.visualstudio.microsoft.com/download/pr/9a742ba1-7005-474a-a3f2-1773d5154855/0AE222509664B38F9DB0CBC06A854D4D76756444198794EF67E1A00367546729/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/9a742ba1-7005-474a-a3f2-1773d5154855/C130730363D41DAAD63F50FDD7F5F58D02B7803C65E816768CAFFC76CAD5F7B1/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/17d9414e-c7e7-40b7-9a3c-e76e18d20c93/10F7C46005564BAD8E8FA1F4AE05C9E2BD6497814F70D57FD03FA82D45478976/VC_redist.arm64.exe
```

14.25.28508.3
```
https://download.visualstudio.microsoft.com/download/pr/3583e96f-8b5f-4f63-bdfe-5c039fcd7b5e/B6C82087A2C443DB859FDBEAAE7F46244D06C3F2A7F71C35E50358066253DE52/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/3583e96f-8b5f-4f63-bdfe-5c039fcd7b5e/AC96016F1511AE3EB5EC9DE04551146FE351B7F97858DCD67163912E2302F5D6/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/b2494dde-a7d8-4a8e-a159-79577450a5d0/905FD9E265168C1C8C5FC3DFEE5DE6092FEAA841BFFDA4C31DFF359C552EB956/VC_redist.arm64.exe
https://download.visualstudio.microsoft.com/download/pr/8c211be1-c537-4402-82e7-a8fb5ee05e8a/B6C82087A2C443DB859FDBEAAE7F46244D06C3F2A7F71C35E50358066253DE52/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/8c211be1-c537-4402-82e7-a8fb5ee05e8a/AC96016F1511AE3EB5EC9DE04551146FE351B7F97858DCD67163912E2302F5D6/VC_redist.x86.exe
```

14.24.28127.4
```
https://download.visualstudio.microsoft.com/download/pr/3b070396-b7fb-4eee-aa8b-102a23c3e4f4/40EA2955391C9EAE3E35619C4C24B5AAF3D17AEAA6D09424EE9672AA9372AEED/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/9307e627-aaac-42cb-a32a-a39e166ee8cb/E59AE3E886BD4571A811FE31A47959AE5C40D87C583F786816C60440252CD7EC/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/9307e627-aaac-42cb-a32a-a39e166ee8cb/B19C24546CA5481CC03D1A326DCE4516D7A483FA166B32F1D46D508C1E700EC3/VC_redist.arm64.exe
https://download.visualstudio.microsoft.com/download/pr/348da5f2-c5d4-4fbf-8360-d1b907780672/E59AE3E886BD4571A811FE31A47959AE5C40D87C583F786816C60440252CD7EC/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/348da5f2-c5d4-4fbf-8360-d1b907780672/B19C24546CA5481CC03D1A326DCE4516D7A483FA166B32F1D46D508C1E700EC3/VC_redist.arm64.exe
```

14.23.27820.0
```
https://download.visualstudio.microsoft.com/download/pr/9565895b-35a6-434b-a881-11a6f4beec76/EE84FED2552E018E854D4CD2496DF4DD516F30733A27901167B8A9882119E57C/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/9565895b-35a6-434b-a881-11a6f4beec76/4A8157B2FF422C259DDAA2D0E568C0C0AFAB940E1F6E0E482EF83E90DDBAD2D6/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/acb33d47-fc02-4dfd-b5fb-d3a3fc43471a/a4632676aef805244c06934ab2aae242/vc_redist.arm64.exe
```

14.22.27821.0
```
https://download.visualstudio.microsoft.com/download/pr/cc0046d4-e7b4-45a1-bd46-b1c079191224/9c4042a4c2e6d1f661f4c58cf4d129e9/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/0c1cfec3-e028-4996-8bb7-0c751ba41e32/1abed1573f36075bfdfc538a2af00d37/vc_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/d7a97409-d551-414b-b925-399baf002bd6/3b43999988b6dc103986d6b504a21b93/vc_redist.arm64.exe
```

14.22.27807.1
```
https://download.visualstudio.microsoft.com/download/pr/47b48be7-d142-48ab-a1b1-64648aed1bfd/74d2f2b3503e0da2e542fea2a6af2cdc/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/7fdc0ca4-d643-4c2e-b19d-95c2b86ccb22/bd5624675be5a17788cac0ab64f8970e/vc_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/f3470ac0-3a6f-4a52-8298-3f426701ab59/5034d8f17f7d5596093de007f9d3d60b/vc_redist.arm64.exe
```

14.22.27724.0
```
https://download.visualstudio.microsoft.com/download/pr/3f622df0-1966-48d4-8c46-19371ba468a0/f7e40e8ff4c6801443d314a898e00bdd/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/268cecd3-1e5d-422d-9e1f-587090702fa0/db7ed27ef373a0ae27245aa67b79c6d5/vc_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/d72e97a2-79f3-4393-b1ea-e0ee0d1c5f08/725cdd8193ed0ace2249b31854ecdf39/vc_redist.arm64.exe
```

14.22.27706.1
```
https://download.visualstudio.microsoft.com/download/pr/2d52b992-f8b2-4f56-b46b-7c8587d8fac6/1a58244e89c9b9dd5c576c943725c0eb/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/e7b22ebe-6367-43f2-a62d-cd7b6edb9962/783c356f72da20c843128bb5219862d2/vc_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/7dcb4d57-3e71-4088-83dd-30d942a9f3ae/33fc4f37f033357c7dfd385fb4655b4a/vc_redist.arm64.exe
```

14.21.27702.2
```
https://download.visualstudio.microsoft.com/download/pr/9e04d214-5a9d-4515-9960-3d71398d98c3/1e1e62ab57bbb4bf5199e8ce88f040be/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/c8edbb87-c7ec-4500-a461-71e8912d25e9/99ba493d660597490cbb8b3211d2cae4/vc_redist.x86.exe
```

14.21.27619.1
```
https://download.visualstudio.microsoft.com/download/pr/b28932f6-8d79-46f1-8385-e0a8bdf3c1e0/1adf822fa2d810d2c736bf97efe84e34/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/59e7fad0-c074-49e8-a815-77cb7083f910/9d4c6916d07433832c836646e65e81df/vc_redist.x86.exe
```

14.20.27607.1
```
https://download.visualstudio.microsoft.com/download/pr/0eac0881-2173-4d79-bee7-fda4dccb0005/aa1dfcd3b6c304fa8b8b57d1e3d6ae63/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/1a6314bb-c949-42e9-925f-1c0bf4eb00de/41482628dd05373a7c24b0d43ae1753e/vc_redist.x86.exe
```

14.20.27508.1
```
https://download.visualstudio.microsoft.com/download/pr/21614507-28c5-47e3-973f-85e7f66545a4/f3a2caa13afd59dd0e57ea374dbe8855/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/092cda8f-872f-47fd-b549-54bbb8a81877/ddc5ec3f90091ca690a67d0d697f1242/vc_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/643ddeaf-8cb0-47d0-a643-a3f787f461eb/1DD1CCAC627034D368393FC9C49F8D3A439AC33A2298347CA055FB7C6D2FF011/VC_redist.arm64.exe
```
</details>

______________________________

<details><summary>2017</summary>


14.20.27404.0
```
https://download.visualstudio.microsoft.com/download/pr/2db56484-9419-45d1-b02c-1cb23d85d45b/7bb6c9d792c1d26679b1af8effd630f2/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/57c9f522-4aaf-4036-8c7b-9a0034359359/2cb6bf088adfc7f54e122b468effa879/vc_redist.x86.exe
```

14.20.27323.0
```
https://download.visualstudio.microsoft.com/download/pr/1577e5d9-4000-49e4-a76f-974f47715c1e/1f3238178cac6d30960d8a7a6af515a3/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/810f730d-4094-41b3-ab0e-aa3314b57288/da301e7b495be0d806e385931d0321d8/vc_redist.x86.exe
```

14.16.27305.0
```
https://download.visualstudio.microsoft.com/download/pr/ddec9dfe-f1b5-4e78-b576-31c4c401b693/5c831021d2ca44f1915ed7f8705f8fde/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/9fc98793-5b02-4fb2-9bca-04ea54a7b98d/2c922a55fb6d2808cfcd5935c666088a/vc_redist.x86.exe
```

14.16.27033.0
```
https://download.visualstudio.microsoft.com/download/pr/26191127-a48f-463c-acab-e39ee856f30b/5B0CBB977F2F5253B1EBE5C9D30EDBDA35DBD68FB70DE7AF5FAAC6423DB575B5/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/4100b84d-1b4d-487d-9f89-1354a7138c8f/5B0CBB977F2F5253B1EBE5C9D30EDBDA35DBD68FB70DE7AF5FAAC6423DB575B5/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/3c46b1eb-b8ad-48d6-b22f-6213a3b3be58/31e51c713d0fb3a7686c3449f86ef34c/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/2b5bcd2f-0dbc-4b83-90a3-3b1c5ae77e62/0252474394129dbab6ff9ce24f1c6a3c/vc_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/3ef6bbdc-37ad-433b-a7ae-a2101be8b072/df1d993145485c695ea96a9222e12ac8/vc_redist.arm64.exe
https://download.visualstudio.microsoft.com/download/pr/26191127-a48f-463c-acab-e39ee856f30b/E0AD3FDD0D4CD9F1BB1589F23AB73991CAA8EEA374F59DCB9E0B46D1422A6BE6/VC_redist.arm64.exe
https://download.visualstudio.microsoft.com/download/pr/4100b84d-1b4d-487d-9f89-1354a7138c8f/E0AD3FDD0D4CD9F1BB1589F23AB73991CAA8EEA374F59DCB9E0B46D1422A6BE6/VC_redist.arm64.exe
```

14.16.27029.1
```
https://download.visualstudio.microsoft.com/download/pr/906d2e4a-c423-4c85-bfd9-d0fa35640dfe/34ef2b9a75badb8926d2820bac3639f8/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/09a93ed7-32d3-4a52-8c4c-ba26eb1465de/8a3d68179def218fea8dc987c5c01eb6/vc_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/cf45ec71-d4d7-480e-affc-e75e89e0349b/9e1367fcaabe85e254817b18ee39e2a7/vc_redist.arm64.exe
```

14.16.27027.1
```
https://download.visualstudio.microsoft.com/download/pr/36c5faaf-bd8b-433f-b3d7-2af73bae10a8/212f41f2ccffee6d6dc27f901b7d77a1/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/e9e1e87c-5bba-49fa-8bad-e00f0527f9bc/8e641901c2257dda7f0d3fd26541e07a/vc_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/14276100-0b76-4787-9443-f5d9e3be9532/26b2215bf08256af3ddb80892b14f087/vc_redist.arm64.exe
```

14.16.27024.1
```
https://download.visualstudio.microsoft.com/download/pr/da111512-4cd1-4373-8e9c-b7756169a7fc/9847cddac1fa50cb4c609d3440dbbfdd/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/feb07965-6bd2-4448-a42c-f7e44b14b2bd/e967de02e250191d8743fed0a99300cc/vc_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/d5873e09-f580-4e55-896d-88dd8b97f58d/02f09136713a170d7cbb571fa626a615/vc_redist.arm64.exe
```

14.16.27023.1
```
https://download.visualstudio.microsoft.com/download/pr/9fbed7c7-7012-4cc0-a0a3-a541f51981b5/e7eec15278b4473e26d7e32cef53a34c/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/d0b808a8-aa78-4250-8e54-49b8c23f7328/9c5e6532055786367ee61aafb3313c95/vc_redist.x86.exe
```

14.16.27012.6
```
https://download.visualstudio.microsoft.com/download/pr/f4b43ad3-8847-4630-9df9-3910ce3ebaaf/e0acacec5e6f7e0fe2c0b4be495bf1a0/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/418c1c23-c3b9-40f4-aa7f-c29a4428938f/6cdc605d4ba860a0ab86cace32894b0b/vc_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/ec23352c-a742-453a-9b2e-3a2132b69661/564487308ad325ff0cfccf9b89e885c7/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/ad7b10f2-178d-4147-9f29-dc15fed99860/73a98387d598066aedecfb1740e09095/vc_redist.x86.exe
```

14.15.26706.0
```
https://download.visualstudio.microsoft.com/download/pr/21ac5efc-11b4-43ff-8c53-5e204b1abdc5/16acba795c9a429c6dd4c26570f40cab/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/a091cf7f-0c4a-4880-adc7-925046c2d227/fc4906e2d327380e4a320d677795ca8c/vc_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/20ef12bb-5283-41d7-90f7-eb3bb7355de7/8b58fd89f948b2430811db3da92299a6/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/749aa419-f9e4-4578-a417-a43786af205e/d59197078cc425377be301faba7dd87a/vc_redist.x86.exe
```

14.15.26626.1
```
https://download.visualstudio.microsoft.com/download/pr/40540ada-0c94-4fd5-96a0-5f7186628b96/cd4090733c623b9dc71fc2361115c200/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/30fb3093-fd68-4fd2-a89e-5bf9d82d4afe/b64fcef8b6025637adaa30fbc3bf25b7/vc_redist.x86.exe
```

14.15.26608.1
```
https://download.visualstudio.microsoft.com/download/pr/ecd5a72e-cd0f-4086-9e54-d70572c0dfd8/622a0624ebce07df3d0eaadeceeef3bb/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/776d6fb9-1c03-47fa-a6d5-7eb528198d6f/ddc92bc7e33ce187851e5939ec7b70ab/vc_redist.x86.exe
```

14.14.26429.4
```
https://download.visualstudio.microsoft.com/download/pr/12328699/a80e967515b2a4faf37bf15387f1c5c3/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/12319034/ccd261eb0e095411af3b306273231b68/VC_redist.x86.exe
```

14.14.26405.0
```
https://download.visualstudio.microsoft.com/download/pr/12077385/73e1ab8917c6ee08fb03a230865b9401/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/12076901/9ca0bba83015c844cc98d7cb783370e9/VC_redist.x86.exe
```

14.14.26329.0
```
https://download.visualstudio.microsoft.com/download/pr/11992678/73e1ab8917c6ee08fb03a230865b9401/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/11993435/9ca0bba83015c844cc98d7cb783370e9/VC_redist.x86.exe
```

14.13.26118.0
```
TBD
```

14.13.26020.0
```
https://download.visualstudio.microsoft.com/download/pr/100493959/73e1ab8917c6ee08fb03a230865b9401/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/100486102/9ca0bba83015c844cc98d7cb783370e9/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/11687625/2cd2dba5748dc95950a5c42c2d2d78e4/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/11687613/88b50ce70017bf10f2d56d60fcba6ab1/VC_redist.x86.exe
```

14.12.25810.0
```
https://download.visualstudio.microsoft.com/download/pr/100349091/2cd2dba5748dc95950a5c42c2d2d78e4/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/100349138/88b50ce70017bf10f2d56d60fcba6ab1/VC_redist.x86.exe
```

14.12.25711.0
```
https://download.visualstudio.microsoft.com/download/pr/100084443/73e1ab8917c6ee08fb03a230865b9401/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/100084058/9ca0bba83015c844cc98d7cb783370e9/VC_redist.x86.exe
```

14.11.25506.0
```
TBD
```

14.11.25325.0
```
https://download.visualstudio.microsoft.com/download/pr/f416a087-45c0-4cfe-887e-eb7ae51dd581/aa6845d4723a73d42a5ff2d4c7cc4e1b/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/f416a087-45c0-4cfe-887e-eb7ae51dd581/82baa6d3f51e332f7a7b07f9dadec3a7/vc_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/d3a74387-07e3-4f62-b9ba-70972094b9b6/2362a16102f5d529ede85e8210a297d4/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/d3a74387-07e3-4f62-b9ba-70972094b9b6/f5db89e571f855d9f3bf15567a9e783e/vc_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/10629685/73e1ab8917c6ee08fb03a230865b9401/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/10630635/9ca0bba83015c844cc98d7cb783370e9/VC_redist.x86.exe
https://download.visualstudio.microsoft.com/download/pr/11100230/15ccb3f02745c7b206ad10373cbca89b/VC_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/11100229/78c1e864d806e36f6035d80a0e80399e/VC_redist.x86.exe
```

14.10.25017.0
```
http://download.microsoft.com/download/3/b/f/3bf6e759-c555-4595-8973-86b7b4312927/vc_redist.x64.exe
http://download.microsoft.com/download/1/f/e/1febbdb2-aded-4e14-9063-39fb17e88444/vc_redist.x86.exe
```

14.10.25008.0
```
http://download.microsoft.com/download/5/7/b/57b2947c-7221-4f33-b35e-2fc78cb10df4/vc_redist.x64.exe
http://download.microsoft.com/download/1/d/8/1d8137db-b5bb-4925-8c5d-927424a2e4de/vc_redist.x86.exe
http://download.microsoft.com/download/8/9/d/89d195e1-1901-4036-9a75-fbe46443fc5a/vc_redist.x64.exe
http://download.microsoft.com/download/7/a/6/7a68af9f-3761-4781-809b-b6df0f56d24c/vc_redist.x86.exe
```
</details>

______________________________

<details><summary>2015</summary>


14.10.24516.0
```
http://download.microsoft.com/download/8/C/4/8C46752E-F6FD-43E4-AF10-E046A128CC0A/VC_redist.x64.exe
http://download.microsoft.com/download/0/5/2/05271FE6-CBA8-4A4D-9E95-00CFC60C1639/VC_redist.x86.exe
http://download.microsoft.com/download/6/2/4/62491095-34D6-4FB0-BB14-22293D193397/VC_redist.x64.exe
http://download.microsoft.com/download/5/B/1/5B188FBD-9CCA-46D2-AE4C-BC50DF7E8828/VC_redist.x86.exe
```

14.0.24406.0
```
http://download.microsoft.com/download/e/7/8/e7842dea-ed59-4703-9a9e-5c05e89686f5/vc_redist.x64.exe
http://download.microsoft.com/download/c/5/0/c50ddaed-1286-4a0f-ba29-63ea2d6b2bc2/vc_redist.x86.exe
```

14.0.24215.1
```
https://www.microsoft.com/en-us/download/details.aspx?id=53840
http://download.microsoft.com/download/6/A/A/6AA4EDFF-645B-48C5-81CC-ED5963AEAD48/vc_redist.x64.exe
http://download.microsoft.com/download/6/A/A/6AA4EDFF-645B-48C5-81CC-ED5963AEAD48/vc_redist.x86.exe
http://download.microsoft.com/download/1/F/0/1F01DD22-748C-41A7-89DE-54D64355CDA6/vc_redist.x64.exe
http://download.microsoft.com/download/1/F/0/1F01DD22-748C-41A7-89DE-54D64355CDA6/vc_redist.x86.exe
http://download.microsoft.com/download/2/7/8/2785a456-bd65-4d6f-b491-96711022a3be/enu_MICUP/vcredistd14x64/vc_redist.x64.exe
http://download.microsoft.com/download/2/7/8/2785a456-bd65-4d6f-b491-96711022a3be/enu_MICUP/vcredistd14x86/vc_redist.x86.exe
https://rserverdistribution.azureedge.net/production/redist/VCRT/14.0.24215.1/DLC/1033/7dd907ae6d47482ebdfa36a3ebe7d434/vc_redist.x64.exe
```

14.0.24212.0
```
https://www.microsoft.com/en-us/download/details.aspx?id=53587
http://download.microsoft.com/download/2/a/2/2a2ef9ab-1b4b-49f0-9131-d33f79544e70/vc_redist.x64.exe
http://download.microsoft.com/download/9/a/2/9a2a7e36-a8af-46c0-8a78-a5eb111eefe2/vc_redist.x86.exe
http://download.microsoft.com/download/6/D/F/6DF3FF94-F7F9-4F0B-838C-A328D1A7D0EE/vc_redist.x64.exe
http://download.microsoft.com/download/6/D/F/6DF3FF94-F7F9-4F0B-838C-A328D1A7D0EE/vc_redist.x86.exe
http://download.microsoft.com/download/c/2/3/c232fa4c-72da-43f8-9a5d-2d860ce5abc0/enu_MICUP/vcredistd14x64/vc_redist.x64.exe
http://download.microsoft.com/download/c/2/3/c232fa4c-72da-43f8-9a5d-2d860ce5abc0/enu_MICUP/vcredistd14x86/vc_redist.x86.exe
http://download.microsoft.com/download/3/9/a/39a4c3fc-613f-4c2e-a314-c41bd1535044/enu_MICUP/vcredistd14x64/vc_redist.x64.exe
http://download.microsoft.com/download/3/9/a/39a4c3fc-613f-4c2e-a314-c41bd1535044/enu_MICUP/vcredistd14x86/vc_redist.x86.exe
```

14.0.24210.0
```
http://download.microsoft.com/download/2/c/6/2c675af0-2155-4961-b32e-289d7addfcec/vc_redist.x64.exe
http://download.microsoft.com/download/d/e/c/dec58546-c2f5-40a7-b38e-4df8d60b9764/vc_redist.x86.exe
```

14.0.24123.0
```
https://www.microsoft.com/en-us/download/details.aspx?id=52685
http://download.microsoft.com/download/0/6/4/064F84EA-D1DB-4EAA-9A5C-CC2F0FF6A638/vc_redist.x64.exe
http://download.microsoft.com/download/0/6/4/064F84EA-D1DB-4EAA-9A5C-CC2F0FF6A638/vc_redist.x86.exe
http://download.microsoft.com/download/0/8/f/08ffb798-a0ed-46a0-9efb-e24ef0d281e5/enu_COMM_SL2/vcredistd14x64/vc_redist.x64.exe
http://download.microsoft.com/download/0/8/f/08ffb798-a0ed-46a0-9efb-e24ef0d281e5/enu_COMM_SL2/vcredistd14x86/vc_redist.x86.exe
```

14.0.24109.0
```
http://download.microsoft.com/download/f/3/6/f36aaf39-28c5-481c-94ae-eb32338f1a42/enu_RM_CLIENT/vcredistd14x64/vc_redist.x64.exe
http://download.microsoft.com/download/f/3/6/f36aaf39-28c5-481c-94ae-eb32338f1a42/enu_RM_CLIENT/vcredistd14x86/vc_redist.x86.exe
```

14.0.24018.0
```
http://download.microsoft.com/download/5/2/a/52abcc54-d42c-45dc-b2e3-a34da7b3c1cc/enu_ENT/vcredistd14x64/vc_redist.x64.exe
http://download.microsoft.com/download/5/2/a/52abcc54-d42c-45dc-b2e3-a34da7b3c1cc/enu_ENT/vcredistd14x86/vc_redist.x86.exe
```

14.0.23918.0
```
http://download.microsoft.com/download/4/c/b/4cbd5757-0dd4-43a7-bac0-2a492cedbacb/vc_redist.x64.exe
http://download.microsoft.com/download/f/3/9/f39b30ec-f8ef-4ba3-8cb4-e301fcf0e0aa/vc_redist.x86.exe
http://download.microsoft.com/download/0/2/5/02596cd9-63cd-4c90-8e13-073ff0fe7fb5/vc_redist.arm.exe
```

14.0.23910.0
```
http://download.microsoft.com/download/0/9/8/098f52fc-d597-485e-8282-0188c5a94d5a/enu_ENT/vcredistd14x64/vc_redist.x64.exe
http://download.microsoft.com/download/0/9/8/098f52fc-d597-485e-8282-0188c5a94d5a/enu_ENT/vcredistd14x86/vc_redist.x86.exe
```

14.0.23907.0
```
http://download.microsoft.com/download/5/5/3/5532a287-5746-4332-a2be-173c9c118a9b/enu_ENT/vcredistd14x64/vc_redist.x64.exe
http://download.microsoft.com/download/5/5/3/5532a287-5746-4332-a2be-173c9c118a9b/enu_ENT/vcredistd14x86/vc_redist.x86.exe
```

14.0.23824.1
```
http://download.microsoft.com/download/9/3/7/937bcec8-37db-4be6-a296-9d0cf1d88ff7/enu_comm_sl3/vcredistd14x64/vc_redist.x64.exe
http://download.microsoft.com/download/8/2/c/82c972ab-8a40-4d4b-86cf-24a984c5cf7f/enu_comm_sl4/vcredistd14x86/vc_redist.x86.exe
```

14.0.23816.0
```
https://download.visualstudio.microsoft.com/download/pr/367ac30e-219f-463a-86b6-ccf9e4c69ad9/5f438bdd6cddb6e96682957abd71c349/vc_redist.x64.exe
https://download.visualstudio.microsoft.com/download/pr/367ac30e-219f-463a-86b6-ccf9e4c69ad9/b411e41483b9f0c66571156b85a196dd/vc_redist.x86.exe
http://download.microsoft.com/download/9/4/0/9404687e-4064-4d0e-a944-ad319f90458f/enu_TFS_OFF/vcredistd14x64/vc_redist.x64.exe
http://download.microsoft.com/download/9/4/0/9404687e-4064-4d0e-a944-ad319f90458f/enu_TFS_OFF/vcredistd14x86/vc_redist.x86.exe
http://download.microsoft.com/download/c/e/4/ce4cfd4d-c9a3-4560-b675-4aa22ef2b02c/enu_TFS_OFF/vcredistd14x64/vc_redist.x64.exe
http://download.microsoft.com/download/c/e/4/ce4cfd4d-c9a3-4560-b675-4aa22ef2b02c/enu_TFS_OFF/vcredistd14x86/vc_redist.x86.exe
http://download.microsoft.com/download/f/8/4/f849e4ff-3eba-4b1d-b409-c08af0a63e59/enu_TFS_OFF/vcredistd14x64/vc_redist.x64.exe
http://download.microsoft.com/download/f/8/4/f849e4ff-3eba-4b1d-b409-c08af0a63e59/enu_TFS_OFF/vcredistd14x86/vc_redist.x86.exe
http://download.microsoft.com/download/4/c/d/4cd0e566-ea03-46d2-819f-239d5156e396/enu_TFS_OFF/vcredistd14x64/vc_redist.x64.exe
http://download.microsoft.com/download/4/c/d/4cd0e566-ea03-46d2-819f-239d5156e396/enu_TFS_OFF/vcredistd14x86/vc_redist.x86.exe
http://download.microsoft.com/download/e/f/2/ef201134-fb51-481f-8afd-da1194a785fd/enu_TFS_OFF/vcredistd14x64/vc_redist.x64.exe
http://download.microsoft.com/download/e/f/2/ef201134-fb51-481f-8afd-da1194a785fd/enu_TFS_OFF/vcredistd14x86/vc_redist.x86.exe
http://download.microsoft.com/download/b/0/9/b099c801-d7c5-426f-989f-420929a9329e/enu_TFS_OFF/vcredistd14x64/vc_redist.x64.exe
http://download.microsoft.com/download/b/0/9/b099c801-d7c5-426f-989f-420929a9329e/enu_TFS_OFF/vcredistd14x86/vc_redist.x86.exe
http://download.microsoft.com/download/1/3/e/13ec6ec9-2076-4f9a-901e-7e67d0fa5833/enu_TFS_OFF/vcredistd14x64/vc_redist.x64.exe
http://download.microsoft.com/download/1/3/e/13ec6ec9-2076-4f9a-901e-7e67d0fa5833/enu_TFS_OFF/vcredistd14x86/vc_redist.x86.exe
```

14.0.23506.0
```
http://download.microsoft.com/download/C/E/5/CE514EAE-78A8-4381-86E8-29108D78DBD4/VC_redist.x64.exe
http://download.microsoft.com/download/C/E/5/CE514EAE-78A8-4381-86E8-29108D78DBD4/VC_redist.x86.exe
```

14.0.23026.0
```
https://www.microsoft.com/en-us/download/details.aspx?id=48145
http://download.microsoft.com/download/9/3/F/93FCF1E7-E6A4-478B-96E7-D4B285925B00/vc_redist.x64.exe
http://download.microsoft.com/download/9/3/F/93FCF1E7-E6A4-478B-96E7-D4B285925B00/vc_redist.x86.exe
https://rserverdistribution.azureedge.net/production/redist/VCRT/14.0.23026.0/DLC/1033/4f0eec78914443cda93be3ead95e7000/vc_redist.x64.exe
```
</details>

______________________________

## Microsoft Visual C++ 2013 Redistributables - v12

<details><summary>2013</summary>


12.0.40664.0
```
https://support.microsoft.com/en-us/help/4032938/update-for-visual-c-2013-redistributable-package
https://download.visualstudio.microsoft.com/download/pr/10912041/cee5d6bca2ddbcd039da727bf4acb48a/vcredist_x64.exe
https://download.visualstudio.microsoft.com/download/pr/10912113/5da66ddebb0ad32ebd4b922fd82e8e25/vcredist_x86.exe
```

12.0.40660.0
```
https://support.microsoft.com/en-us/help/3179560/update-for-visual-c-2013-and-visual-c-redistributable-package
http://download.microsoft.com/download/0/5/6/056dcda9-d667-4e27-8001-8a0c6971d6b1/vcredist_x64.exe
http://download.microsoft.com/download/0/5/6/056dcda9-d667-4e27-8001-8a0c6971d6b1/vcredist_x86.exe
```

12.0.40649.5
```
https://support.microsoft.com/en-us/help/3138367/update-for-visual-c-2013-and-visual-c-redistributable-package
http://download.microsoft.com/download/C/C/2/CC2DF5F8-4454-44B4-802D-5EA68D086676/vcredist_x64.exe
http://download.microsoft.com/download/C/C/2/CC2DF5F8-4454-44B4-802D-5EA68D086676/vcredist_x86.exe
```

12.0.30501.0 (12.0.21005.1)
```
https://www.microsoft.com/en-us/download/details.aspx?id=40784
http://download.microsoft.com/download/2/E/6/2E61CFA4-993B-4DD4-91DA-3737CD5CD6E3/vcredist_x64.exe
http://download.microsoft.com/download/2/E/6/2E61CFA4-993B-4DD4-91DA-3737CD5CD6E3/vcredist_x86.exe
http://download.microsoft.com/download/2/E/6/2E61CFA4-993B-4DD4-91DA-3737CD5CD6E3/vcredist_arm.exe
https://rserverdistribution.azureedge.net/production/redist/VCRT/12.0.30501.0/DLC/1033/fb23f4dc69264910a4c62d9edbc628fd/vcredist_x64.exe
```

12.0.21005.1
```
https://cuckoo.sh/vmcloak/vcredist_2013_x64.exe
https://cuckoo.sh/vmcloak/vcredist_2013_x86.exe
http://download.microsoft.com/download/A/8/D/A8DC10BB-5299-4057-8FD8-1896B7F5A60B/drop/enu_VS/VCRedistD12x64/vcredist_x64.exe
http://download.microsoft.com/download/A/8/D/A8DC10BB-5299-4057-8FD8-1896B7F5A60B/drop/enu_VS/VCRedistD12x86/vcredist_x86.exe
http://download.microsoft.com/download/0/2/F/02F628CC-6818-462A-B6F4-F78E0E41F7FA/Drop/enu_VS/VCRedistD12x64/vcredist_x64.exe
http://download.microsoft.com/download/0/2/F/02F628CC-6818-462A-B6F4-F78E0E41F7FA/Drop/enu_VS/VCRedistD12x86/vcredist_x86.exe
http://download.microsoft.com/download/6/e/2/6e27cce7-57c7-48d3-b990-32dfd3fbba24/enu_ENT/vcredistd12x64/vcredist_x64.exe
http://download.microsoft.com/download/6/e/2/6e27cce7-57c7-48d3-b990-32dfd3fbba24/enu_ENT/vcredistd12x86/vcredist_x86.exe
http://download.microsoft.com/download/5/2/a/52abcc54-d42c-45dc-b2e3-a34da7b3c1cc/enu_ENT/vcredistd12x64/vcredist_x64.exe
http://download.microsoft.com/download/5/2/a/52abcc54-d42c-45dc-b2e3-a34da7b3c1cc/enu_ENT/vcredistd12x86/vcredist_x86.exe
```
</details>

______________________________

## Microsoft Visual C++ 2012 Redistributables - v11

<details><summary>2012</summary>


11.0.61135.400
```
https://www.microsoft.com/en-us/download/details.aspx?id=53340
http://download.microsoft.com/download/3/B/C/3BC60F47-6A7C-4D46-8CFB-C2E746EF336E/vc_uwpdesktop.110.exe
```

11.0.61030.0
```
https://www.microsoft.com/en-us/download/details.aspx?id=30679
http://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU_4/vcredist_x64.exe
http://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU_4/vcredist_x86.exe
http://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU4/vcredist_arm.exe
http://download.windowsupdate.com/d/msdownload/update/software/crup/2015/02/vcredist_x64_1a5d93dddbc431ab27b1da711cd3370891542797.exe
http://download.windowsupdate.com/d/msdownload/update/software/crup/2015/02/vcredist_x86_96b377a27ac5445328cbaae210fc4f0aaa750d3f.exe
```

11.0.60610.1
```
http://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU3/vcredist_x64.exe
http://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU3/vcredist_x86.exe
http://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU3/vcredist_arm.exe
```

11.0.51106.1
```
http://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU1/vcredist_x64.exe
http://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU1/vcredist_x86.exe
http://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU1/vcredist_arm.exe
```

11.0.50727.1
```
http://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/vcredist_arm.exe
http://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/vcredist_x64.exe
http://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/vcredist_x86.exe
```
</details>

______________________________

## Microsoft Visual C++ 2010 Redistributables - v10

<details><summary>2010</summary>


10.0.40219.473 SP1
```
https://www.microsoft.com/en-us/download/details.aspx?id=54179
http://download.microsoft.com/download/E/E/0/EE05C9EF-A661-4D9E-BCE2-6961ECDF087F/vcredist_x64.exe
http://download.microsoft.com/download/E/E/0/EE05C9EF-A661-4D9E-BCE2-6961ECDF087F/vcredist_x86.exe
```

10.0.40219.455 SP1
```
https://support.microsoft.com/en-us/help/2890375
https://support.microsoft.com/en-us/help/2889080
```

10.0.40219.447 SP1
```
https://support.microsoft.com/en-us/help/2821701
```

10.0.40219.436 SP1
```
https://support.microsoft.com/en-us/help/2689322
```

10.0.40219.434 SP1
```
https://support.microsoft.com/en-us/help/2723430
```

10.0.40219.414 SP1
```
https://support.microsoft.com/en-us/help/2608539
```

10.0.40219.325 SP1
```
https://www.microsoft.com/en-us/download/details.aspx?id=26999
http://download.microsoft.com/download/1/6/5/165255E7-1014-4D0A-B094-B6A430A6BFFC/vcredist_x64.exe
http://download.microsoft.com/download/1/6/5/165255E7-1014-4D0A-B094-B6A430A6BFFC/vcredist_x86.exe
http://download.microsoft.com/download/E/4/1/E41A6614-9FB0-4675-8A97-08F8B1A1827D/vcredist_x86.exe
http://download.windowsupdate.com/msdownload/update/software/secu/2011/07/vcredist_x64_15d032d669078aa6f0f7fd1cbf4115a070bd034d.exe
http://download.windowsupdate.com/msdownload/update/software/secu/2011/07/vcredist_x86_28c54491be70c38c97849c3d8cfbfdd0d3c515cb.exe
https://download.visualstudio.microsoft.com/download/pr/bc7c5ad8-2fdd-4d83-98fe-d0dad91e0336/eaddcb5f93b436783646ee27069551f4/vc_redist.x64.exe
```

10.0.40219.1 SP1
```
https://www.microsoft.com/en-us/download/details.aspx?id=13523
https://www.microsoft.com/en-us/download/details.aspx?id=8328
http://download.microsoft.com/download/A/8/0/A80747C3-41BD-45DF-B505-E9710D2744E0/vcredist_x64.exe
http://download.microsoft.com/download/C/6/D/C6D0FD4E-9E53-4897-9B91-836EBA2AACD3/vcredist_x86.exe
```

10.0.30319.460 RTM
```
https://www.microsoft.com/en-us/download/details.aspx?id=26351
https://gitlab.com/stdout12/adns/uploads/3e276dcc502cef90e93365d5a3b8241e/VCRedist_x64_10.0.30319.460.exe
https://gitlab.com/stdout12/adns/uploads/2a73615407ff331431df3804786b9824/VCRedist_x86_10.0.30319.460.exe
```

10.0.30319.415 RTM
```
https://www.microsoft.com/en-us/download/details.aspx?id=21576
http://download.microsoft.com/download/4/D/0/4D00D6C0-09FC-446C-AE9C-C923AF2DF29A/vcredist_x64.exe
http://download.microsoft.com/download/4/D/0/4D00D6C0-09FC-446C-AE9C-C923AF2DF29A/vcredist_x86.exe
http://download.windowsupdate.com/msdownload/update/software/secu/2011/03/vcredist_x64_b19211187caa726619fefd80f199bf7df3266bb7.exe
http://download.windowsupdate.com/msdownload/update/software/secu/2011/03/vcredist_x86_f5420aa2ac335ce211623a1aa8e16fcf547cfe9a.exe
```

10.0.30319.1 RTM
```
https://download.microsoft.com/download/3/2/2/3224B87F-CFA0-4E70-BDA3-3DE650EFEBA5/vcredist_x64.exe
https://download.microsoft.com/download/5/B/C/5BC5DBB3-652D-4DCE-B14A-475AB85EEF6E/vcredist_x86.exe
http://web.archive.org/web/20140711193530/http://www.microsoft.com/en-us/download/details.aspx?id=14632
http://web.archive.org/web/20140702152445/http://www.microsoft.com/en-us/download/details.aspx?id=5555
http://web.archive.org/web/20140803163818if_/http://download.microsoft.com/download/3/2/2/3224B87F-CFA0-4E70-BDA3-3DE650EFEBA5/vcredist_x64.exe
http://web.archive.org/web/20140729085618if_/http://download.microsoft.com/download/5/B/C/5BC5DBB3-652D-4DCE-B14A-475AB85EEF6E/vcredist_x86.exe
https://download.visualstudio.microsoft.com/download/pr/d3a74387-07e3-4f62-b9ba-70972094b9b6/e3bcbbade2a8552a4c34800df7d72301/vc_redist.x64.exe
```
</details>

______________________________

## Microsoft Visual C++ 2008 Redistributables - v9

<details><summary>2008</summary>


9.0.30729.7523 (EXE 9.0.30729.7039) SP1
```
https://support.microsoft.com/en-us/help/2834565
https://gitlab.com/stdout12/adns/uploads/0f07341a2ba4f97011c7d9f567dc1684/vcredist_x64_9.0.30729.7523.exe
https://gitlab.com/stdout12/adns/uploads/bba8b7855325681d9849c766f439a614/vcredist_x86_9.0.30729.7523.exe
https://1drv.ms/u/s!AlaD0_9bis3SgZBu1LmVQrMDUKZCaQ
```

9.0.30729.6161 (EXE 9.0.30729.5677) SP1
```
https://www.microsoft.com/en-us/download/details.aspx?id=26368
http://download.microsoft.com/download/5/D/8/5D8C65CB-C849-4025-8E95-C3966CAFD8AE/vcredist_x64.exe
http://download.microsoft.com/download/5/D/8/5D8C65CB-C849-4025-8E95-C3966CAFD8AE/vcredist_x86.exe
http://download.windowsupdate.com/msdownload/update/software/secu/2011/05/vcredist_x64_a7c83077b8a28d409e36316d2d7321fa0ccdb7e8.exe
http://download.windowsupdate.com/msdownload/update/software/secu/2011/05/vcredist_x86_470640aa4bb7db8e69196b5edb0010933569e98d.exe
```

9.0.30729.4148 SP1
```
https://www.microsoft.com/en-us/download/details.aspx?id=11895
http://download.microsoft.com/download/9/7/7/977B481A-7BA6-4E30-AC40-ED51EB2028F2/vcredist_x64.exe
http://download.microsoft.com/download/9/7/7/977B481A-7BA6-4E30-AC40-ED51EB2028F2/vcredist_x86.exe
```

9.0.30729.17 SP1
```
http://web.archive.org/web/20180101031655/https://www.microsoft.com/en-us/download/details.aspx?id=2092
http://web.archive.org/web/20181228234950/https://www.microsoft.com/en-us/download/details.aspx?id=5582
http://web.archive.org/web/20170712121155/https://download.microsoft.com/download/2/d/6/2d61c766-107b-409d-8fba-c39e61ca08e8/vcredist_x64.exe
http://web.archive.org/web/20190228220826/https://download.microsoft.com/download/d/d/9/dd9a82d0-52ef-40db-8dab-795376989c03/vcredist_x86.exe
```

9.0.30411.0 RTM
```
http://web.archive.org/web/20190419092620/http://www.microsoft.com/en-us/download/details.aspx?id=16771
http://web.archive.org/web/20170311053706/http://www.microsoft.com/en-us/download/details.aspx?id=10015
http://web.archive.org/web/20200803205341/http://download.microsoft.com/download/1/9/0/190da410-d595-4342-ba2f-2422e78bc84d/vcredist_x64.exe
http://web.archive.org/web/20141116100952/http://download.microsoft.com/download/d/1/0/d10d210e-e0ad-4010-b547-bc5e395ef691/vcredist_x86.exe
```

9.0.21022.218 RTM
```
https://www.microsoft.com/en-us/download/details.aspx?id=10430
http://download.microsoft.com/download/A/5/3/A53B40CA-F75C-4678-852A-3C15EA82F186/vcredist_x64.exe
http://download.microsoft.com/download/A/5/3/A53B40CA-F75C-4678-852A-3C15EA82F186/vcredist_x86.exe
```

9.0.21022.8 RTM
```
http://web.archive.org/web/20170301005607/http://www.microsoft.com/en-us/download/details.aspx?id=15336
http://web.archive.org/web/20170201104610/http://www.microsoft.com/en-us/download/details.aspx?id=29
http://web.archive.org/web/20170302190538/http://download.microsoft.com/download/d/2/4/d242c3fb-da5a-4542-ad66-f9661d0a8d19/vcredist_x64.exe
http://web.archive.org/web/20170101214751/http://download.microsoft.com/download/1/1/1/1116b75a-9ec3-481a-a3c8-1777b5381140/vcredist_x86.exe
```
</details>

______________________________

## Microsoft Visual C++ 2005 Redistributables - v8

<details><summary>2005</summary>


8.0.50727.6229 (MSI 8.0.61186/8.0.61187) SP1
```
https://support.microsoft.com/en-us/help/2643995
https://gitlab.com/stdout12/adns/uploads/c1aa6269e6bc0559c640c9dc2b11f98b/vcredist_x64_8.0.50727.6229.exe
https://gitlab.com/stdout12/adns/uploads/6e4cb29579c9ff812e79ffd7746d243a/vcredist_x86_8.0.50727.6229.exe
https://1drv.ms/u/s!AlaD0_9bis3SgZByzKZszfHyq-Xo0g
```

8.0.50727.6195 (MSI 8.0.61000/8.0.61001) SP1
```
https://www.microsoft.com/en-us/download/details.aspx?id=26347
http://download.microsoft.com/download/8/B/4/8B42259F-5D70-43F4-AC2E-4B208FD8D66A/vcredist_x64.exe
http://download.microsoft.com/download/8/B/4/8B42259F-5D70-43F4-AC2E-4B208FD8D66A/vcredist_x86.exe
http://download.windowsupdate.com/msdownload/update/software/secu/2011/06/vcredist_x64_ee916012783024dac67fc606457377932c826f05.exe
http://download.windowsupdate.com/msdownload/update/software/secu/2011/06/vcredist_x86_b8fab0bb7f62a24ddfe77b19cd9a1451abd7b847.exe
```

8.0.50727.4053 (MSI 8.0.59192/8.0.59193) SP1
```
https://www.microsoft.com/en-us/download/details.aspx?id=14431
http://download.microsoft.com/download/6/B/B/6BB661D6-A8AE-4819-B79F-236472F6070C/vcredist_x64.exe
http://download.microsoft.com/download/6/B/B/6BB661D6-A8AE-4819-B79F-236472F6070C/vcredist_x86.exe
```

8.0.50727.762 (MSI 8.0.56336) SP1
```
http://web.archive.org/web/20121208085931/https://www.microsoft.com/en-us/download/details.aspx?id=18471
http://web.archive.org/web/20121231225822/https://www.microsoft.com/en-us/download/details.aspx?id=5638
http://web.archive.org/web/20121208085931/http://download.microsoft.com/download/d/4/1/d41aca8a-faa5-49a7-a5f2-ea0aa4587da0/vcredist_x64.exe
http://web.archive.org/web/20121231225822/http://download.microsoft.com/download/e/1/c/e1c773de-73ba-494a-a5ba-f24906ecf088/vcredist_x86.exe
https://msassist.com/files/VisualCPP/VisualCpp2005-SP1b/vcredist_x64.exe
https://msassist.com/files/VisualCPP/VisualCpp2005-SP1b/vcredist_x86.exe
```

8.0.50727.42 (MSI 8.0.50727.42) RTM
```
http://web.archive.org/web/20121213184646/https://www.microsoft.com/en-us/download/details.aspx?id=21254
http://web.archive.org/web/20121231110729/https://www.microsoft.com/en-us/download/details.aspx?id=3387
http://web.archive.org/web/20120709125308/http://download.microsoft.com/download/9/1/4/914851c6-9141-443b-bdb4-8bad3a57bea9/vcredist_x64.exe
http://web.archive.org/web/20130729085626/http://download.microsoft.com/download/d/3/4/d342efa6-3266-4157-a2ec-5174867be706/vcredist_x86.exe
```
</details>

______________________________

## Microsoft Visual C++ .NET - v7

<details><summary>2002/2003</summary>


.NET 2003 msvcp71.dll - 7.10.6052.0 SP1 / msvcr71.dll - 7.10.7031.4 SP1
```
https://www.betaarchive.com/wiki/index.php/Microsoft_KB_Archive/932298
http://thehotfixshare.net/board/index.php?/topic/12472-vs71sp1-kb932298-x86-enuexe/
```

.NET 2003 MFC71.DLL - 7.10.6119.0 SP1
```
https://www.microsoft.com/en-us/download/details.aspx?id=6818
http://download.microsoft.com/download/9/7/C/97CABE46-5FB8-4240-A54E-4C83B99116D9/VS7.1sp1-KB2465373-X86.exe
```

.NET 2003 MFC71.DLL - 7.10.6101.0 SP1
```
https://www.microsoft.com/en-us/download/details.aspx?id=23288
http://download.microsoft.com/download/D/9/E/D9ECEE52-613F-4327-8147-073882D999F9/VS7.1sp1-KB971089-X86.exe
```

.NET 2003 MFC71.DLL - 7.10.6041.0 SP1
```
https://www.microsoft.com/en-us/download/details.aspx?id=17054
http://download.microsoft.com/download/f/0/5/f052914b-3a0f-4e90-b039-395005f77ef2/VS7.1sp1-KB927696-X86.exe
```

.NET 2003 MFC71.DLL - 7.10.5057.0 RTM
```
http://www.microsoft.com/en-us/download/details.aspx?id=21440
http://download.microsoft.com/download/5/8/6/586ac9db-5039-4955-9dbc-e4556128220f/VS7.1-KB924643-X86.exe
```

.NET 2002 msvcr70.dll - 7.0.9981.0 SP1
```
https://www.betaarchive.com/wiki/index.php/Microsoft_KB_Archive/932304
```

.NET 2002 MFC70.DLL - 7.0.9975.0 SP1
```
https://www.microsoft.com/en-us/download/details.aspx?id=3644
http://download.microsoft.com/download/6/b/e/6be11d8a-e0c7-429c-ac8c-9860e313ced9/VS7.0sp1-KB924642-X86.exe
```

.NET 2002 MFC70.DLL - 7.0.9801.0 RTM
```
https://www.microsoft.com/en-us/download/details.aspx?id=6430
http://download.microsoft.com/download/9/8/0/980abbac-26af-42b9-959e-e104e2ef6579/VS7.0-KB924641-X86.exe
```
</details>

______________________________

## Microsoft Visual Basic 6.0 Runtime Extended Files

<details><summary>VB6</summary>


98.46 / 98.39
```
https://support.microsoft.com/en-us/help/3096896
https://www.microsoft.com/en-us/download/details.aspx?id=50722
http://download.microsoft.com/download/B/A/5/BA51304F-1DFB-4DAE-BC4F-F54323018562/VB60SP6-KB3096896-x86-ENU.msi
```

98.34
```
https://support.microsoft.com/en-us/help/2708437
https://www.microsoft.com/en-us/download/details.aspx?id=30505
http://download.microsoft.com/download/5/6/3/5635D6A9-885E-4C80-A2E7-8A7F4488FBF1/VB60SP6-KB2708437-x86-ENU.msi
```

98.33
```
https://support.microsoft.com/en-us/help/2641426
https://www.microsoft.com/en-us/download/details.aspx?id=29326
http://download.microsoft.com/download/5/6/3/5635D6A9-885E-4C80-A2E7-8A7F4488FBF1/VB60SP6-KB2641426-x86-ENU.msi
```

98.16
```
https://support.microsoft.com/en-us/help/957924
https://www.microsoft.com/en-us/download/details.aspx?id=7030
http://download.microsoft.com/download/5/6/3/5635D6A9-885E-4C80-A2E7-8A7F4488FBF1/VB60SP6-KB957924-v2-x86-ENU.msi
```

98.12
```
https://support.microsoft.com/en-us/help/926857
https://www.microsoft.com/en-us/download/details.aspx?id=7474
http://download.microsoft.com/download/1/A/3/1A30521E-354B-4E4A-9713-7C69199C8447/VB60SP6-KB926857-x86-ENU.msi
```
</details>

______________________________

## Microsoft Visual Basic 5.0 Runtime Files

<details><summary>VB5</summary>


5.2.82.44 Msvbvm50.dll
```
https://web.archive.org/web/20180510233245/https://support.microsoft.com/en-us/help/180071/file-msvbvm50-exe-installs-visual-basic-5-0-run-time-files
https://web.archive.org/web/20180510233245/http://download.microsoft.com/download/vb50pro/utility/1/win98/en-us/msvbvm50.exe
```
</details>

______________________________

## Microsoft Visual Studio 2010 Tools for Office Runtime

<details><summary>VSTOR 2010</summary>


10.0.60917.0 (MSI 10.0.60922)
```
https://www.microsoft.com/en-us/download/details.aspx?id=105890
https://download.microsoft.com/download/5/d/2/5d24f8f8-efbb-4b63-aa33-3785e3104713/vstor_redist.exe
LangPacks
https://www.microsoft.com/en-us/download/details.aspx?id=105891
```

10.0.60912.0 (MSI 10.0.60917)
```
https://www.microsoft.com/en-us/download/details.aspx?id=105671
https://download.microsoft.com/download/c/0/e/c0e39fdf-68c9-4332-b745-5268ed69cb54/vstor_redist.exe
LangPacks
https://www.microsoft.com/en-us/download/details.aspx?id=105672
```

10.0.60910.0 (MSI 10.0.60915)
```
http://download.windowsupdate.com/d/msdownload/update/software/secu/2023/08/vstor_redist_e7a2976ca89418fd18158d4799cdf9493deedc2c.exe
https://www.microsoft.com/en-us/download/details.aspx?id=105522
https://download.microsoft.com/download/8/6/4/8641e164-7796-4b34-81c7-30d24a5bd533/vstor_redist.exe
LangPacks
https://www.microsoft.com/en-us/download/details.aspx?id=105523
```

10.0.60828.0 (MSI 10.0.60833)
```
https://www.microsoft.com/en-us/download/details.aspx?id=56961
http://download.microsoft.com/download/C/A/8/CA86DFA0-81F3-4568-875A-7E7A598D4C1C/vstor_redist.exe
LangPacks
https://www.microsoft.com/de-de/download/details.aspx?id=56962
```

10.0.60825.0 (MSI 10.0.60830)
```
https://www.microsoft.com/en-us/download/details.aspx?id=54251
http://download.microsoft.com/download/F/B/A/FBAB6866-71F8-4A3F-89A4-5BC6AB035C62/vstor_redist.exe
LangPacks
https://www.microsoft.com/en-us/download/details.aspx?id=54246
```

10.0.60724.0 (MSI 10.0.60729)
```
https://www.microsoft.com/en-us/download/details.aspx?id=48217
http://download.microsoft.com/download/7/A/F/7AFA5695-2B52-44AA-9A2D-FC431C231EDC/vstor_redist.exe
LangPacks
https://www.microsoft.com/en-us/download/details.aspx?id=48216
```

10.0.60715.0 (MSI 10.0.60720)
```
https://www.microsoft.com/en-us/download/details.aspx?id=48181
http://download.microsoft.com/download/9/F/4/9F4B3B5E-8348-4015-A4BF-F378EA633B64/vstor_redist.exe
LangPacks
https://www.microsoft.com/en-us/download/details.aspx?id=48180
```

10.0.50903.0 (MSI 10.0.50908)
```
http://download.windowsupdate.com/c/msdownload/update/software/crup/2014/10/vstor_redist_ddecb05a9db2654ad29577b363f5f8e040f59012.exe
```

10.0.50701.0 (MSI 10.0.50706)
```
TBD
```

10.0.50325.0 (MSI 10.0.50330)
```
TBD
```

10.0.40303.0 (MSI 10.0.40308)
```
https://download.microsoft.com/download/9/4/9/949B0B7C-6385-4664-8EA8-3F6038172322/vstor_redist.exe
```

10.0.40219.5 (MSI 10.0.31010)
```
http://download.windowsupdate.com/msdownload/update/software/dflt/2011/10/vstor40_x64_dab149d6dea71c16756e043b596017f000753bef.exe
http://download.windowsupdate.com/msdownload/update/software/dflt/2011/10/vstor40_x86_89770ea9124b58c873773e2551cc184df09ac7a6.exe
LangPacks
https://www.catalog.update.microsoft.com/Search.aspx?q=230b82d1-3abd-471a-a4f9-23f97fb857d9
```

10.0.30319.308 (MSI 10.0.30322)
```
http://download.windowsupdate.com/msdownload/update/software/updt/2010/08/vstor40_x64_cc48341c6dfa78da3b9d29d01a010377bcbbc4b0.exe
http://download.windowsupdate.com/msdownload/update/software/updt/2010/08/vstor40_x86_d9a4d42e2d226be456852a5d109993538e3a669b.exe
```
</details>
